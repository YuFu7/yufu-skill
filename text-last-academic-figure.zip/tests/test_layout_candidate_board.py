#!/usr/bin/env python3
"""Regression tests for the pixel-layout candidate board builder."""

from __future__ import annotations

import hashlib
import json
import struct
import subprocess
import sys
import tempfile
import unittest
import zlib
from pathlib import Path
from xml.etree import ElementTree as ET


SKILL_DIR = Path(__file__).resolve().parents[1]
BUILDER = SKILL_DIR / "scripts" / "build_layout_candidate_board.py"


def png_chunk(chunk_type: bytes, data: bytes) -> bytes:
    crc = zlib.crc32(chunk_type)
    crc = zlib.crc32(data, crc) & 0xFFFFFFFF
    return struct.pack(">I", len(data)) + chunk_type + data + struct.pack(">I", crc)


def make_png(width: int = 8, height: int = 6) -> bytes:
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    raw = b"".join(b"\x00" + bytes([120, 150, 180]) * width for _ in range(height))
    return (
        b"\x89PNG\r\n\x1a\n"
        + png_chunk(b"IHDR", ihdr)
        + png_chunk(b"IDAT", zlib.compress(raw))
        + png_chunk(b"IEND", b"")
    )


class LayoutCandidateBoardTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.first = self.root / "first.png"
        self.second = self.root / "second.png"
        self.board = self.root / "board.svg"
        self.manifest = self.root / "manifest.json"
        self.first.write_bytes(make_png())
        self.second.write_bytes(make_png())

    def tearDown(self) -> None:
        self.temp.cleanup()

    def run_builder(self, *extra: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [
                sys.executable,
                "-B",
                str(BUILDER),
                "--candidate",
                f"L1={self.first}",
                "--candidate",
                f"L2={self.second}",
                "--output",
                str(self.board),
                "--manifest",
                str(self.manifest),
                *extra,
            ],
            text=True,
            capture_output=True,
            check=False,
        )

    def test_valid_candidates_write_board_and_manifest(self) -> None:
        result = self.run_builder()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue(self.board.exists())
        manifest = json.loads(self.manifest.read_text(encoding="utf-8"))
        self.assertEqual(manifest["candidate_count"], 2)
        self.assertEqual(manifest["common_dimensions"], [8, 6])
        self.assertEqual([item["id"] for item in manifest["candidates"]], ["L1", "L2"])
        self.assertEqual(
            manifest["board_sha256"], hashlib.sha256(self.board.read_bytes()).hexdigest()
        )
        ET.parse(self.board)

    def test_existing_output_requires_replace(self) -> None:
        self.assertEqual(self.run_builder().returncode, 0)
        original = self.board.read_bytes()
        result = self.run_builder()
        self.assertEqual(result.returncode, 2)
        self.assertIn("already exists", result.stderr)
        self.assertEqual(self.board.read_bytes(), original)

    def test_dimension_mismatch_fails_without_outputs(self) -> None:
        self.second.write_bytes(make_png(width=9, height=6))
        result = self.run_builder()
        self.assertEqual(result.returncode, 2)
        self.assertIn("do not match", result.stderr)
        self.assertFalse(self.board.exists())
        self.assertFalse(self.manifest.exists())

    def test_duplicate_id_fails(self) -> None:
        result = subprocess.run(
            [
                sys.executable,
                "-B",
                str(BUILDER),
                "--candidate",
                f"L1={self.first}",
                "--candidate",
                f"L1={self.second}",
                "--output",
                str(self.board),
                "--manifest",
                str(self.manifest),
            ],
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(result.returncode, 2)
        self.assertIn("duplicate candidate id", result.stderr)

    def test_corrupt_png_fails_without_outputs(self) -> None:
        payload = bytearray(self.second.read_bytes())
        payload[-5] ^= 1
        self.second.write_bytes(payload)
        result = self.run_builder()
        self.assertEqual(result.returncode, 2)
        self.assertIn("CRC mismatch", result.stderr)
        self.assertFalse(self.board.exists())
        self.assertFalse(self.manifest.exists())

    def test_single_candidate_fails(self) -> None:
        result = subprocess.run(
            [
                sys.executable,
                "-B",
                str(BUILDER),
                "--candidate",
                f"L1={self.first}",
                "--output",
                str(self.board),
                "--manifest",
                str(self.manifest),
            ],
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(result.returncode, 2)
        self.assertIn("candidate count", result.stderr)


if __name__ == "__main__":
    unittest.main()
