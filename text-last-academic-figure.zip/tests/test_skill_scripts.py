#!/usr/bin/env python3
"""Adversarial regression tests for the text-last figure skill."""

from __future__ import annotations

import base64
import copy
import json
import struct
import subprocess
import sys
import tempfile
import unittest
import zlib
from pathlib import Path
from xml.etree import ElementTree as ET


SKILL_DIR = Path(__file__).resolve().parents[1]
COMPOSER = SKILL_DIR / "scripts" / "compose_text_overlay.py"
VALIDATOR = SKILL_DIR / "scripts" / "validate_text_last_svg.py"
SVG_NS = "http://www.w3.org/2000/svg"
ET.register_namespace("", SVG_NS)


def png_chunk(chunk_type: bytes, data: bytes) -> bytes:
    crc = zlib.crc32(chunk_type)
    crc = zlib.crc32(data, crc) & 0xFFFFFFFF
    return (
        struct.pack(">I", len(data))
        + chunk_type
        + data
        + struct.pack(">I", crc)
    )


def make_png(width: int = 8, height: int = 6, duplicate_ihdr: bool = False) -> bytes:
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    rows = []
    for y in range(height):
        pixels = b"".join(
            bytes((x * 17 % 256, y * 23 % 256, 120)) for x in range(width)
        )
        rows.append(b"\x00" + pixels)
    raw = b"".join(rows)
    chunks = png_chunk(b"IHDR", ihdr)
    if duplicate_ihdr:
        chunks += png_chunk(b"IHDR", ihdr)
    return (
        b"\x89PNG\r\n\x1a\n"
        + chunks
        + png_chunk(b"IDAT", zlib.compress(raw))
        + png_chunk(b"IEND", b"")
    )


def valid_spec(width: int = 8, height: int = 6) -> dict[str, object]:
    return {
        "canvas": {"width": width, "height": height},
        "title": "Smoke test",
        "description": "One valid label.",
        "labels": [
            {
                "id": "a",
                "text": "A",
                "x": 2,
                "y": 2,
                "font_size": 1,
                "backplate": {
                    "x": 1,
                    "y": 1,
                    "width": 3,
                    "height": 1,
                    "rx": 0.5,
                    "stroke_width": 0.1,
                },
            }
        ],
    }


class SkillScriptTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.image = self.root / "background.png"
        self.spec = self.root / "labels.json"
        self.output = self.root / "figure.svg"
        self.image.write_bytes(make_png())
        self.spec.write_text(json.dumps(valid_spec()), encoding="utf-8")

    def tearDown(self) -> None:
        self.temp.cleanup()

    def run_command(self, *parts: object) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [sys.executable, "-B", *(str(part) for part in parts)],
            text=True,
            capture_output=True,
            check=False,
        )

    def compose(self, output: Path | None = None, *extra: str) -> subprocess.CompletedProcess[str]:
        return self.run_command(
            COMPOSER,
            "--image",
            self.image,
            "--spec",
            self.spec,
            "--output",
            output or self.output,
            *extra,
        )

    def validate(self, svg: Path | None = None) -> subprocess.CompletedProcess[str]:
        return self.run_command(VALIDATOR, svg or self.output, "--json")

    def test_valid_linked_svg_passes(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        result = self.validate()
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        self.assertEqual(json.loads(result.stdout)["verdict"], "PASS")

    def test_valid_inline_svg_passes(self) -> None:
        inline = self.root / "inline.svg"
        self.assertEqual(self.compose(inline, "--inline").returncode, 0)
        self.assertEqual(self.validate(inline).returncode, 0)

    def test_existing_output_is_not_overwritten(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        before = self.output.read_bytes()
        second = self.compose()
        self.assertEqual(second.returncode, 2)
        self.assertIn("output already exists", second.stderr)
        self.assertEqual(self.output.read_bytes(), before)

    def test_explicit_replace_is_required_and_works(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        replaced = self.compose(self.output, "--replace")
        self.assertEqual(replaced.returncode, 0, replaced.stderr)
        self.assertEqual(self.validate().returncode, 0)

    def test_overlapping_footprints_fail(self) -> None:
        spec = valid_spec()
        duplicate = copy.deepcopy(spec["labels"][0])
        duplicate["id"] = "b"
        duplicate["text"] = "B"
        spec["labels"].append(duplicate)
        self.spec.write_text(json.dumps(spec), encoding="utf-8")
        result = self.compose()
        self.assertEqual(result.returncode, 2)
        self.assertIn("label footprints overlap", result.stderr)
        self.assertFalse(self.output.exists())

    def test_invalid_optional_value_fails(self) -> None:
        spec = valid_spec()
        spec["labels"][0]["opacity"] = 2
        self.spec.write_text(json.dumps(spec), encoding="utf-8")
        result = self.compose()
        self.assertEqual(result.returncode, 2)
        self.assertIn("must be in [0, 1]", result.stderr)

    def test_unexpected_spec_field_fails(self) -> None:
        spec = valid_spec()
        spec["labels"][0]["transform"] = "rotate(45)"
        self.spec.write_text(json.dumps(spec), encoding="utf-8")
        result = self.compose()
        self.assertEqual(result.returncode, 2)
        self.assertIn("unexpected fields", result.stderr)

    def test_canvas_dimension_mismatch_fails(self) -> None:
        spec = valid_spec(width=9, height=6)
        self.spec.write_text(json.dumps(spec), encoding="utf-8")
        result = self.compose()
        self.assertEqual(result.returncode, 2)
        self.assertIn("do not match canvas", result.stderr)

    def test_absolute_link_to_non_png_content_fails(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        image = tree.getroot().find(f"{{{SVG_NS}}}image")
        image.set("href", "/etc/hosts")
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("absolute, empty, or traversing", result.stdout)

    def test_traversing_link_fails(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        image = tree.getroot().find(f"{{{SVG_NS}}}image")
        image.set("href", "../background.png")
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("absolute, empty, or traversing", result.stdout)

    def test_truncated_inline_png_fails(self) -> None:
        inline = self.root / "inline.svg"
        self.assertEqual(self.compose(inline, "--inline").returncode, 0)
        tree = ET.parse(inline)
        image = tree.getroot().find(f"{{{SVG_NS}}}image")
        payload = base64.b64encode(b"\x89PNG\r\n\x1a\n").decode()
        image.set("href", f"data:image/png;base64,{payload}")
        tree.write(inline, encoding="utf-8", xml_declaration=True)
        result = self.validate(inline)
        self.assertEqual(result.returncode, 2)
        self.assertIn("embedded PNG is invalid", result.stdout)

    def test_corrupt_png_crc_fails(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        payload = bytearray(self.image.read_bytes())
        payload[-5] ^= 0x01
        self.image.write_bytes(payload)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("CRC mismatch", result.stdout)

    def test_png_viewbox_dimension_mismatch_fails(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        root = tree.getroot()
        root.set("viewBox", "0 0 8 7")
        root.set("height", "7")
        image = root.find(f"{{{SVG_NS}}}image")
        image.set("height", "7")
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("do not match viewBox", result.stdout)

    def test_full_canvas_rect_fails(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        rect = tree.getroot().find(f".//{{{SVG_NS}}}rect")
        rect.set("width", "8")
        rect.set("height", "6")
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("not compact", result.stdout)

    def test_noncanonical_geometry_fails(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        layer = tree.getroot().find(f"{{{SVG_NS}}}g")
        ET.SubElement(layer, f"{{{SVG_NS}}}path", {"d": "M0 0L1 1"})
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("must be a group", result.stdout)

    def test_unexpected_svg_attribute_fails(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        layer = tree.getroot().find(f"{{{SVG_NS}}}g")
        layer.set("transform", "translate(1,1)")
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("unexpected attributes", result.stdout)

    def test_zero_physical_width_fails(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        tree.getroot().set("width", "0")
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("must be finite and positive", result.stdout)

    def test_missing_physical_dimensions_fail(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        root = tree.getroot()
        root.attrib.pop("width")
        root.attrib.pop("height")
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("svg width is required", result.stdout)

    def test_physical_aspect_mismatch_fails(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        tree.getroot().set("height", "100px")
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("aspect does not match viewBox", result.stdout)

    def test_duplicate_ihdr_fails(self) -> None:
        inline = self.root / "inline.svg"
        self.assertEqual(self.compose(inline, "--inline").returncode, 0)
        tree = ET.parse(inline)
        image = tree.getroot().find(f"{{{SVG_NS}}}image")
        payload = base64.b64encode(make_png(duplicate_ihdr=True)).decode()
        image.set("href", f"data:image/png;base64,{payload}")
        tree.write(inline, encoding="utf-8", xml_declaration=True)
        result = self.validate(inline)
        self.assertEqual(result.returncode, 2)
        self.assertIn("exactly one IHDR", result.stdout)

    def test_text_anchor_outside_footprint_fails(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        text = tree.getroot().find(f".//{{{SVG_NS}}}text")
        text.set("x", "7")
        text.set("y", "5")
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("anchor lies outside its footprint", result.stdout)

    def test_overlapping_collision_footprints_fail(self) -> None:
        spec = valid_spec()
        spec["labels"] = [
            {
                "id": "a",
                "text": "A",
                "x": 1,
                "y": 1,
                "font_size": 1,
                "collision_box": {
                    "x": 0.5,
                    "y": 0.5,
                    "width": 1.5,
                    "height": 1
                }
            },
            {
                "id": "b",
                "text": "B",
                "x": 6,
                "y": 5,
                "font_size": 1,
                "collision_box": {
                    "x": 5,
                    "y": 4.5,
                    "width": 2,
                    "height": 1
                }
            }
        ]
        self.spec.write_text(json.dumps(spec), encoding="utf-8")
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        rects = tree.getroot().findall(f".//{{{SVG_NS}}}rect")
        for key in ("x", "y", "width", "height"):
            rects[1].set(key, rects[0].get(key))
        texts = tree.getroot().findall(f".//{{{SVG_NS}}}text")
        texts[1].set("x", texts[0].get("x"))
        texts[1].set("y", texts[0].get("y"))
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("label footprints overlap", result.stdout)

    def test_missing_font_family_fails(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        text = tree.getroot().find(f".//{{{SVG_NS}}}text")
        text.attrib.pop("font-family")
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("font-family", result.stdout)

    def test_invisible_text_fill_fails(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        text = tree.getroot().find(f".//{{{SVG_NS}}}text")
        text.set("fill", "none")
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("must be visible", result.stdout)

    def test_zero_text_opacity_fails(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        text = tree.getroot().find(f".//{{{SVG_NS}}}text")
        text.set("opacity", "0")
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("text opacity is invalid", result.stdout)

    def test_utf16_dtd_entity_fails_before_xml_parse(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        source = self.output.read_text(encoding="utf-8")
        source = source.replace(
            "?>",
            "?>\n<!DOCTYPE svg [<!ENTITY injected 'Expanded'>]>",
            1,
        )
        source = source.replace(">Smoke test</title>", ">&injected;</title>", 1)
        self.output.write_bytes(source.encode("utf-16"))
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("canonical UTF-8", result.stdout)

    def test_zero_width_text_fails(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        text = tree.getroot().find(f".//{{{SVG_NS}}}text")
        text.text = "\u200b"
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("control or format characters", result.stdout)

    def test_combining_only_text_fails(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        text = tree.getroot().find(f".//{{{SVG_NS}}}text")
        text.text = "\u0301"
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("no renderable base character", result.stdout)

    def test_comma_only_font_family_fails(self) -> None:
        self.assertEqual(self.compose().returncode, 0)
        tree = ET.parse(self.output)
        text = tree.getroot().find(f".//{{{SVG_NS}}}text")
        text.set("font-family", ",")
        tree.write(self.output, encoding="utf-8", xml_declaration=True)
        result = self.validate()
        self.assertEqual(result.returncode, 2)
        self.assertIn("empty font family", result.stdout)

    def test_composer_rejects_zero_width_text(self) -> None:
        spec = valid_spec()
        spec["labels"][0]["text"] = "\u200b"
        self.spec.write_text(json.dumps(spec), encoding="utf-8")
        result = self.compose()
        self.assertEqual(result.returncode, 2)
        self.assertIn("control/format characters", result.stderr)
        self.assertFalse(self.output.exists())

    def test_composer_rejects_comma_only_font_family(self) -> None:
        spec = valid_spec()
        spec["font_family"] = ","
        self.spec.write_text(json.dumps(spec), encoding="utf-8")
        result = self.compose()
        self.assertEqual(result.returncode, 2)
        self.assertIn("empty font family", result.stderr)
        self.assertFalse(self.output.exists())


if __name__ == "__main__":
    unittest.main()
