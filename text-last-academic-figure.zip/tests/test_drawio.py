#!/usr/bin/env python3
"""Small regression suite for native hybrid assembly, not visual approval."""

import base64
import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET

from test_skill_scripts import make_png

SKILL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL / "scripts"))
from build_drawio import compile_scene
from probe_drawio import loopback_url


class DrawioTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.base = Path(self.temp.name)
        self.scene = json.loads((SKILL / "assets/example.scene.json").read_text())

    def tearDown(self):
        self.temp.cleanup()

    def cells(self, text_free=False):
        payload, counts = compile_scene(self.scene, self.base, text_free)
        return {c.get("id"): c for c in ET.fromstring(payload).iter("mxCell")}, counts

    def test_native_geometry_attached_edges_and_routing(self):
        cells, counts = self.cells()
        self.assertEqual(counts, {"nodes": 4, "edges": 3, "images": 0, "labels": 5})
        self.assertEqual(cells["method"].get("vertex"), "1")
        self.assertEqual(cells["input-method"].get("target"), "method")
        self.assertIn("exitX=0.5;", cells["feedback"].get("style"))
        self.assertEqual(len(cells["feedback"].findall(".//mxPoint")), 2)

    def test_text_free_preserves_geometry(self):
        original, _ = self.cells()
        hidden, _ = self.cells(True)
        for ident, cell in hidden.items():
            if cell.get("vertex") or cell.get("edge"):
                self.assertEqual(cell.get("value"), "")
                self.assertEqual(ET.tostring(cell.find("mxGeometry")),
                                 ET.tostring(original[ident].find("mxGeometry")))

    def test_embedded_image_group_and_editable_label(self):
        payload = make_png()
        (self.base / "asset.png").write_bytes(payload)
        self.scene["nodes"] += [
            {"id": "g", "kind": "group", "x": 50, "y": 270, "width": 160, "height": 140},
            {"id": "icon", "kind": "image", "parent": "g", "asset": "asset.png",
             "x": 0, "y": 0, "width": 80, "height": 60},
            {"id": "name", "kind": "label", "parent": "g", "text": "设备 A & B < C",
             "x": 0, "y": 70, "width": 160, "height": 40}]
        cells, counts = self.cells()
        style = cells["icon"].get("style")
        embedded = style.split("image=data:image/png,")[1].split(";")[0]
        self.assertEqual(base64.b64decode(embedded), payload)
        self.assertEqual(cells["icon"].get("parent"), "g")
        self.assertEqual(cells["name"].get("value"), "设备 A & B < C")
        self.assertEqual(counts["images"], 1)

    def test_invalid_topology_geometry_and_shapes_fail(self):
        for change in ("duplicate", "endpoint", "parent", "bounds", "shape", "nan"):
            with self.subTest(change=change):
                old = copy.deepcopy(self.scene)
                if change == "duplicate":
                    self.scene["edges"][0]["id"] = "input"
                elif change == "endpoint":
                    self.scene["edges"][0]["target"] = "missing"
                elif change == "parent":
                    self.scene["nodes"][0]["parent"] = "method"
                elif change == "bounds":
                    self.scene["nodes"][0]["x"] = 960
                elif change == "shape":
                    self.scene["nodes"][1]["shape"] = "unknown"
                else:
                    self.scene["nodes"][1]["width"] = float("nan")
                with self.assertRaises(ValueError):
                    self.cells()
                self.scene = old

    def test_cli_refuses_overwrite(self):
        output = self.base / "example.drawio"
        command = [sys.executable, "-B", str(SKILL / "scripts/build_drawio.py"),
                   "--spec", str(SKILL / "assets/example.scene.json"), "--output", str(output)]
        first = subprocess.run(command, capture_output=True, text=True)
        self.assertEqual(first.returncode, 0, first.stderr)
        saved = output.read_bytes()
        second = subprocess.run(command, capture_output=True, text=True)
        self.assertEqual(second.returncode, 2)
        self.assertEqual(output.read_bytes(), saved)

    def test_probe_loopback_only(self):
        self.assertEqual(loopback_url("http://127.0.0.1:9333/"), "http://127.0.0.1:9333")
        for url in ("http://0.0.0.0:9333", "http://example.org", "https://localhost", "http://u:p@localhost"):
            with self.subTest(url=url), self.assertRaises(ValueError):
                loopback_url(url)


if __name__ == "__main__":
    unittest.main()
