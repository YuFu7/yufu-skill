#!/usr/bin/env python3
"""Compile a small explicit scene to native, uncompressed Draw.io XML."""

from __future__ import annotations

import argparse
import base64
import json
import math
import re
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

from text_last_png import validate_png_bytes


LAYERS = ("background", "connections", "modules", "assets", "labels")
KINDS = {
    "module": ("modules", {"shape": "rectangle", "rounded": 1}),
    "group": ("modules", {"shape": "rectangle", "fillColor": "none",
                           "strokeColor": "none", "container": 1, "collapsible": 0}),
    "image": ("assets", {"shape": "image", "imageAspect": 1,
                         "aspect": "fixed", "fillColor": "none", "strokeColor": "none"}),
    "label": ("labels", {"shape": "text", "fillColor": "none", "strokeColor": "none"}),
}
SHAPES = {"rectangle": "rectanglePerimeter", "ellipse": "ellipsePerimeter",
          "rhombus": "rhombusPerimeter"}
DEFAULT = {"fontFamily": "Arial", "fontSize": 18, "fontColor": "#243247",
           "fillColor": "#F2F6FA", "strokeColor": "#526780", "strokeWidth": 1.5,
           "whiteSpace": "wrap", "align": "center", "verticalAlign": "middle",
           "spacing": 6}


def number(value, name, positive=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be numeric")
    if not math.isfinite(value) or (positive and value <= 0):
        raise ValueError(f"{name} must be finite" + (" and positive" if positive else ""))
    return value


def style_text(style):
    parts = []
    for key, value in style.items():
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9]*", key):
            raise ValueError(f"invalid style key: {key}")
        if not isinstance(value, (str, int, float)) or isinstance(value, bool):
            raise ValueError(f"invalid style value: {key}")
        value = str(value)
        if any(c in value for c in ";\n\r") or (key == "image" and not value.startswith("data:image/png,")):
            raise ValueError(f"invalid style value: {key}")
        parts.append(f"{key}={value};")
    return "".join(parts)


def compile_scene(scene, base_dir, text_free=False):
    width = number(scene["canvas"]["width"], "canvas.width", True)
    height = number(scene["canvas"]["height"], "canvas.height", True)
    nodes, edges = scene.get("nodes", []), scene.get("edges", [])
    if not nodes:
        raise ValueError("nodes must not be empty")
    ids = {"0", "1", *("layer-" + layer for layer in LAYERS)}
    by_id = {}
    for item in [*nodes, *edges]:
        ident = item["id"]
        if not isinstance(ident, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]*", ident):
            raise ValueError("object IDs must be stable XML-safe strings")
        if ident in ids:
            raise ValueError(f"duplicate/reserved ID: {ident}")
        ids.add(ident)
    for node in nodes:
        if node.get("kind", "module") not in KINDS:
            raise ValueError(f"unsupported kind: {node.get('kind')}")
        parent = node.get("parent")
        if parent and (parent not in by_id or by_id[parent].get("kind", "module") not in ("group", "module")):
            raise ValueError("parent must be a previously declared group or module")
        by_id[node["id"]] = node

    file = ET.Element("mxfile", host="text-last-academic-figure")
    page = ET.SubElement(file, "diagram", id="page-1", name=str(scene.get("title", "Figure")))
    model = ET.SubElement(page, "mxGraphModel", grid="0", guides="1", connect="1",
                          arrows="1", page="1", pageScale="1", pageWidth=str(width),
                          pageHeight=str(height), math="0", shadow="0", background="#FFFFFF")
    root = ET.SubElement(model, "root")
    ET.SubElement(root, "mxCell", id="0")
    ET.SubElement(root, "mxCell", id="1", parent="0")
    for layer in LAYERS:
        ET.SubElement(root, "mxCell", id="layer-" + layer, value=layer, parent="0")

    counts = {"nodes": len(nodes), "edges": len(edges), "images": 0, "labels": 0}
    for node in nodes:
        kind = node.get("kind", "module")
        layer, kind_style = KINDS[kind]
        layer = node.get("layer", layer)
        if layer not in LAYERS:
            raise ValueError(f"unknown layer: {layer}")
        style = {**DEFAULT, **scene.get("style", {}), **kind_style, **node.get("style", {})}
        if kind == "module":
            shape = node.get("shape", "rectangle")
            if shape not in SHAPES:
                raise ValueError(f"unsupported shape: {shape}")
            style.update(shape=shape, perimeter=SHAPES[shape])
        else:
            # Structural properties cannot be changed by decorative overrides.
            style["shape"] = kind_style["shape"]
        x, y, w, h = [number(node[k], node["id"] + "." + k, k in ("width", "height"))
                      for k in ("x", "y", "width", "height")]
        parent = node.get("parent")
        bound_w, bound_h = (by_id[parent]["width"], by_id[parent]["height"]) if parent else (width, height)
        if x < 0 or y < 0 or x + w > bound_w or y + h > bound_h:
            raise ValueError(f"{node['id']} extends outside its parent/canvas")
        if kind == "image":
            image_path = Path(node["asset"])
            if not image_path.is_absolute():
                image_path = base_dir / image_path
            payload = image_path.read_bytes()
            validate_png_bytes(payload)
            # mxGraph style delimiters forbid ';base64'; Draw.io restores it.
            style["image"] = "data:image/png," + base64.b64encode(payload).decode("ascii")
            style["imageAspect"] = 1
            counts["images"] += 1
        elif "image" in style:
            raise ValueError("images must be explicit image nodes")
        value = node.get("text", "")
        if not isinstance(value, str) or (kind in ("image", "group") and value):
            raise ValueError("text must be a string; use child labels for images/groups")
        counts["labels"] += bool(value)
        style["html"] = 0
        cell = ET.SubElement(root, "mxCell", id=node["id"], value="" if text_free else value,
                             style=style_text(style), vertex="1", parent=parent or "layer-" + layer)
        ET.SubElement(cell, "mxGeometry", x=str(x), y=str(y), width=str(w), height=str(h),
                      **{"as": "geometry"})

    for edge in edges:
        for key in ("source", "target"):
            if edge[key] not in by_id or by_id[edge[key]].get("kind") == "label":
                raise ValueError(f"edge {edge['id']} has invalid {key}")
        ports = edge.get("ports", [1, 0.5, 0, 0.5])
        if len(ports) != 4 or any(not 0 <= number(p, "port") <= 1 for p in ports):
            raise ValueError("ports must contain four numbers in [0, 1]")
        style = {"edgeStyle": "orthogonalEdgeStyle", "rounded": 0,
                 "strokeColor": DEFAULT["strokeColor"], "strokeWidth": 1.5,
                 "fontFamily": DEFAULT["fontFamily"], "fontSize": 16,
                 "fontColor": DEFAULT["fontColor"], "endArrow": "block", "endFill": 1,
                 "labelBackgroundColor": "#FFFFFF", **edge.get("style", {}),
                 "exitX": ports[0], "exitY": ports[1], "entryX": ports[2], "entryY": ports[3],
                 "exitPerimeter": 1, "entryPerimeter": 1, "html": 0}
        if "image" in style:
            raise ValueError("images must be explicit image nodes")
        value = edge.get("text", "")
        if not isinstance(value, str):
            raise ValueError("edge text must be a string")
        counts["labels"] += bool(value)
        cell = ET.SubElement(root, "mxCell", id=edge["id"], value="" if text_free else value,
                             style=style_text(style), edge="1", parent="layer-connections",
                             source=edge["source"], target=edge["target"])
        geom = ET.SubElement(cell, "mxGeometry", relative="1", **{"as": "geometry"})
        if edge.get("points"):
            points = ET.SubElement(geom, "Array", **{"as": "points"})
            for point in edge["points"]:
                if len(point) != 2:
                    raise ValueError("waypoints must be [x, y] pairs")
                px, py = number(point[0], "point.x"), number(point[1], "point.y")
                if not (0 <= px <= width and 0 <= py <= height):
                    raise ValueError("waypoint outside canvas")
                ET.SubElement(points, "mxPoint", x=str(px), y=str(py))
    ET.indent(file)
    return ET.tostring(file, encoding="utf-8", xml_declaration=True), counts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--text-free", action="store_true", help="Hide labels but retain geometry.")
    args = parser.parse_args()
    try:
        if args.output.suffix.lower() != ".drawio":
            raise ValueError("output must have .drawio extension")
        scene = json.loads(args.spec.read_text(encoding="utf-8"))
        payload, counts = compile_scene(scene, args.spec.resolve().parent, args.text_free)
        # Exclusive creation protects manually edited masters; use a new filename.
        with args.output.open("xb") as output:
            output.write(payload)
        print(json.dumps({"output": str(args.output), "backend": "file", **counts,
                          "text_free": args.text_free, "visual_verified": False}))
        return 0
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
