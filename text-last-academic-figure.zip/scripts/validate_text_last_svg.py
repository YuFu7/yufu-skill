#!/usr/bin/env python3
"""Fail-closed validation for a canonical text-last hybrid academic SVG."""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import math
import os
import re
import sys
import tempfile
import unicodedata
from pathlib import Path
from urllib.parse import unquote, urlsplit
from xml.etree import ElementTree as ET

from text_last_png import PngError, validate_png_bytes, validate_png_path


SVG = "http://www.w3.org/2000/svg"
ROOT_ATTRS = {"width", "height", "viewBox", "role", "aria-labelledby"}
IMAGE_ATTRS = {
    "id",
    "x",
    "y",
    "width",
    "height",
    "preserveAspectRatio",
    "href",
}
RECT_ATTRS = {
    "data-role",
    "x",
    "y",
    "width",
    "height",
    "rx",
    "fill",
    "fill-opacity",
    "stroke",
    "stroke-width",
}
TEXT_ATTRS = {
    "x",
    "y",
    "text-anchor",
    "font-family",
    "font-size",
    "font-weight",
    "font-style",
    "fill",
    "letter-spacing",
    "opacity",
}
LABEL_ID = re.compile(r"^label-[A-Za-z_][A-Za-z0-9_.-]{0,127}$")
COLOR = re.compile(r"^#(?:[0-9A-Fa-f]{3,4}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$")
NAMED_COLORS = {"black", "white", "transparent", "none"}
LENGTH = re.compile(
    r"^(?P<value>(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)"
    r"(?P<unit>in|cm|mm|pt|pc|px)?$"
)
UNIT_TO_INCH = {
    "": 1 / 96,
    "px": 1 / 96,
    "in": 1,
    "cm": 1 / 2.54,
    "mm": 1 / 25.4,
    "pt": 1 / 72,
    "pc": 1 / 6,
}
MAX_SVG_BYTES = 256 * 1024 * 1024
XML_DECLARATION = re.compile(
    r"\A<\?xml\s+version=(?P<q>['\"])1\.0(?P=q)\s+"
    r"encoding=(?P<e>['\"])utf-8(?P=e)\s*\?>",
    re.IGNORECASE,
)


class SvgError(ValueError):
    """Raised when an SVG violates the canonical layer contract."""


def qname(name: str) -> str:
    return f"{{{SVG}}}{name}"


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def finite(value: str, field: str) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise SvgError(f"{field} must be numeric") from exc
    if not math.isfinite(number):
        raise SvgError(f"{field} must be finite")
    return number


def exact_attributes(element: ET.Element, allowed: set[str], field: str) -> None:
    keys = set(element.attrib)
    unexpected = keys - allowed
    if unexpected:
        raise SvgError(f"{field} has unexpected attributes: {sorted(unexpected)}")


def color_value(value: str | None, field: str) -> None:
    if value is None or (
        not COLOR.fullmatch(value) and value.lower() not in NAMED_COLORS
    ):
        raise SvgError(f"{field} is not an allowed color")


def visible_color(value: str | None, field: str) -> None:
    color_value(value, field)
    assert value is not None
    lowered = value.lower()
    if lowered in {"none", "transparent"}:
        raise SvgError(f"{field} must be visible")
    if lowered.startswith("#"):
        alpha = None
        if len(lowered) == 5:
            alpha = lowered[-1]
        elif len(lowered) == 9:
            alpha = lowered[-2:]
        if alpha is not None and int(alpha, 16) == 0:
            raise SvgError(f"{field} has zero alpha")


def font_family_value(value: str | None, field: str) -> None:
    if value is None or not value.strip() or len(value) > 256:
        raise SvgError(f"{field} is missing or too long")
    families = value.split(",")
    if not families or any(not item.strip() for item in families):
        raise SvgError(f"{field} contains an empty font family")
    for item in families:
        family = item.strip()
        if family[:1] in {"'", '"'}:
            if len(family) < 3 or family[-1] != family[0]:
                raise SvgError(f"{field} contains an invalid quoted family")
            family = family[1:-1]
        if not family or not any(
            unicodedata.category(char)[0] in {"L", "N"} for char in family
        ):
            raise SvgError(f"{field} contains a family without letters or numbers")
        if any(
            not (
                unicodedata.category(char)[0] in {"L", "N"}
                or char in {" ", "-", "_", "."}
            )
            for char in family
        ):
            raise SvgError(f"{field} contains unsupported family syntax")


def visible_text_value(value: str | None, field: str, maximum: int) -> None:
    if value is None or not value.strip() or len(value) > maximum:
        raise SvgError(f"{field} is empty or too long")
    if any(unicodedata.category(char)[0] == "C" for char in value):
        raise SvgError(f"{field} contains control or format characters")
    if not any(
        unicodedata.category(char)[0] in {"L", "N", "P", "S"} for char in value
    ):
        raise SvgError(f"{field} has no renderable base character")


def physical_length(value: str | None, field: str) -> float:
    if value is None:
        raise SvgError(f"{field} is required")
    match = LENGTH.fullmatch(value)
    if match is None:
        raise SvgError(f"{field} has an unsupported length or unit")
    number = float(match.group("value"))
    if not math.isfinite(number) or number <= 0:
        raise SvgError(f"{field} must be finite and positive")
    unit = match.group("unit") or ""
    return number * UNIT_TO_INCH[unit]


def rectangles_intersect(a: dict[str, float], b: dict[str, float]) -> bool:
    return not (
        a["x"] + a["width"] <= b["x"]
        or b["x"] + b["width"] <= a["x"]
        or a["y"] + a["height"] <= b["y"]
        or b["y"] + b["height"] <= a["y"]
    )


def parse_viewbox(root: ET.Element) -> tuple[int, int]:
    values = root.attrib.get("viewBox", "").split()
    if len(values) != 4:
        raise SvgError("viewBox must have four numeric values")
    numbers = [finite(item, "viewBox") for item in values]
    if numbers[0] != 0 or numbers[1] != 0:
        raise SvgError("viewBox origin must be 0 0")
    if numbers[2] <= 0 or numbers[3] <= 0:
        raise SvgError("viewBox dimensions must be positive")
    if not numbers[2].is_integer() or not numbers[3].is_integer():
        raise SvgError("viewBox dimensions must be integers")
    return int(numbers[2]), int(numbers[3])


def decode_image(svg_path: Path, href: str) -> tuple[int, int]:
    if href.startswith("data:image/png;base64,"):
        encoded = href.split(",", 1)[1]
        try:
            payload = base64.b64decode(encoded, validate=True)
        except (ValueError, base64.binascii.Error) as exc:
            raise SvgError("embedded PNG payload is invalid base64") from exc
        try:
            return validate_png_bytes(payload)
        except PngError as exc:
            raise SvgError(f"embedded PNG is invalid: {exc}") from exc

    parsed = urlsplit(href)
    if parsed.scheme or parsed.netloc or parsed.query or parsed.fragment:
        raise SvgError("linked PNG must be a plain local relative path")
    decoded = unquote(parsed.path)
    relative = Path(decoded)
    if relative.is_absolute() or ".." in relative.parts or not relative.parts:
        raise SvgError("linked PNG path is absolute, empty, or traversing")
    base = svg_path.parent.resolve()
    target = (base / relative).resolve()
    try:
        target.relative_to(base)
    except ValueError as exc:
        raise SvgError("linked PNG resolves outside the SVG directory") from exc
    if target.suffix.lower() != ".png":
        raise SvgError("linked substrate must end in .png")
    try:
        return validate_png_path(target)
    except PngError as exc:
        raise SvgError(f"linked PNG is invalid: {exc}") from exc


def validate(svg_path: Path) -> dict[str, object]:
    payload = svg_path.read_bytes()
    if len(payload) > MAX_SVG_BYTES:
        raise SvgError("SVG exceeds the input size limit")
    try:
        decoded = payload.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise SvgError("SVG must use canonical UTF-8 encoding") from exc
    if XML_DECLARATION.match(decoded) is None:
        raise SvgError("SVG must start with a canonical UTF-8 XML declaration")
    upper = decoded.upper()
    if "<!DOCTYPE" in upper or "<!ENTITY" in upper:
        raise SvgError("DTD and entity declarations are not allowed")
    root = ET.fromstring(decoded)
    if root.tag != qname("svg"):
        raise SvgError("root must be an SVG-namespace <svg>")
    exact_attributes(root, ROOT_ATTRS, "svg")
    if root.attrib.get("role") != "img" or root.attrib.get("aria-labelledby") != "title desc":
        raise SvgError("svg accessibility attributes are not canonical")
    width, height = parse_viewbox(root)
    physical_width = physical_length(root.attrib.get("width"), "svg width")
    physical_height = physical_length(root.attrib.get("height"), "svg height")
    physical_aspect = physical_width / physical_height
    viewbox_aspect = width / height
    if abs(physical_aspect / viewbox_aspect - 1) > 1e-4:
        raise SvgError("svg physical width/height aspect does not match viewBox")
    children = list(root)
    expected = [qname("title"), qname("desc"), qname("image"), qname("g")]
    if [item.tag for item in children] != expected:
        raise SvgError("root children must be exactly title, desc, image, editable-text-layer")

    title, desc, image, text_layer = children
    exact_attributes(title, {"id"}, "title")
    exact_attributes(desc, {"id"}, "desc")
    if title.attrib.get("id") != "title" or desc.attrib.get("id") != "desc":
        raise SvgError("title/desc identifiers are not canonical")
    if list(title) or list(desc):
        raise SvgError("title and desc must contain plain non-empty text")
    visible_text_value(title.text, "title", 256)
    visible_text_value(desc.text, "desc", 1024)

    exact_attributes(image, IMAGE_ATTRS, "image")
    expected_image = {
        "id": "text-free-substrate",
        "x": "0",
        "y": "0",
        "width": str(width),
        "height": str(height),
        "preserveAspectRatio": "xMidYMid meet",
    }
    for key, expected_value in expected_image.items():
        if image.attrib.get(key) != expected_value:
            raise SvgError(f"image {key} must be {expected_value!r}")
    href = image.attrib.get("href")
    if not href:
        raise SvgError("image href is missing")
    png_size = decode_image(svg_path, href)
    if png_size != (width, height):
        raise SvgError(
            f"PNG dimensions {png_size[0]}x{png_size[1]} do not match viewBox "
            f"{width}x{height}"
        )

    exact_attributes(text_layer, {"id"}, "editable-text-layer")
    if text_layer.attrib.get("id") != "editable-text-layer":
        raise SvgError("fourth root child must be g#editable-text-layer")
    label_groups = list(text_layer)
    if not label_groups:
        raise SvgError("editable-text-layer has no labels")
    seen_ids: set[str] = set()
    backplates: list[tuple[str, dict[str, float]]] = []
    rect_count = 0
    backplate_count = 0
    collision_count = 0
    text_count = 0
    for index, group in enumerate(label_groups):
        if group.tag != qname("g"):
            raise SvgError(f"label child {index} must be a group")
        exact_attributes(group, {"id"}, f"label group {index}")
        group_id = group.attrib.get("id", "")
        if not LABEL_ID.fullmatch(group_id) or group_id in seen_ids:
            raise SvgError(f"label group {index} has invalid or duplicate id")
        seen_ids.add(group_id)
        items = list(group)
        if [item.tag for item in items] != [qname("rect"), qname("text")]:
            raise SvgError(
                f"{group_id} must contain exactly one footprint rect followed by one text"
            )
        rect = items[0]
        exact_attributes(rect, RECT_ATTRS, f"{group_id} rect")
        role = rect.attrib.get("data-role")
        if role not in {"backplate", "collision-footprint"}:
            raise SvgError(f"{group_id} rect data-role is invalid")
        box = {
            "x": finite(rect.attrib.get("x", ""), f"{group_id} rect x"),
            "y": finite(rect.attrib.get("y", ""), f"{group_id} rect y"),
            "width": finite(rect.attrib.get("width", ""), f"{group_id} rect width"),
            "height": finite(
                rect.attrib.get("height", ""), f"{group_id} rect height"
            ),
        }
        if (
            box["x"] < 0
            or box["y"] < 0
            or box["width"] <= 0
            or box["height"] <= 0
            or box["x"] + box["width"] > width
            or box["y"] + box["height"] > height
            or box["width"] > 0.6 * width
            or box["height"] > 0.2 * height
        ):
            raise SvgError(
                f"{group_id} footprint is outside the canvas or not compact"
            )
        radius = finite(rect.attrib.get("rx", ""), f"{group_id} rect rx")
        fill_opacity = finite(
            rect.attrib.get("fill-opacity", ""), f"{group_id} rect fill-opacity"
        )
        stroke_width = finite(
            rect.attrib.get("stroke-width", ""), f"{group_id} rect stroke-width"
        )
        if role == "backplate":
            if not 0 <= radius <= min(box["width"], box["height"]) / 2:
                raise SvgError(f"{group_id} backplate rx is invalid")
            if not 0 < fill_opacity <= 1 or not 0 <= stroke_width <= 20:
                raise SvgError(f"{group_id} backplate visibility is invalid")
            visible_color(rect.attrib.get("fill"), f"{group_id} backplate fill")
            color_value(rect.attrib.get("stroke"), f"{group_id} backplate stroke")
            backplate_count += 1
        else:
            expected_collision_style = {
                "rx": "0",
                "fill": "none",
                "fill-opacity": "0",
                "stroke": "none",
                "stroke-width": "0",
            }
            for key, expected_value in expected_collision_style.items():
                if rect.attrib.get(key) != expected_value:
                    raise SvgError(
                        f"{group_id} collision footprint {key} must be {expected_value!r}"
                    )
            collision_count += 1
        for other_id, other in backplates:
            if rectangles_intersect(box, other):
                raise SvgError(f"label footprints overlap: {group_id} intersects {other_id}")
        backplates.append((group_id, box))
        rect_count += 1

        text = items[1]
        exact_attributes(text, TEXT_ATTRS, f"{group_id} text")
        if list(text):
            raise SvgError(f"{group_id} text must be plain and non-empty")
        visible_text_value(text.text, f"{group_id} text", 256)
        text_x = finite(text.attrib.get("x", ""), f"{group_id} text x")
        text_y = finite(text.attrib.get("y", ""), f"{group_id} text y")
        font_size = finite(
            text.attrib.get("font-size", ""), f"{group_id} text font-size"
        )
        if (
            not 0 <= text_x <= width
            or not 0 <= text_y <= height
            or font_size <= 0
            or font_size > min(width, height) / 3
        ):
            raise SvgError(f"{group_id} text position or size is invalid")
        if not (
            box["x"] <= text_x <= box["x"] + box["width"]
            and box["y"] <= text_y <= box["y"] + box["height"]
        ):
            raise SvgError(f"{group_id} text anchor lies outside its footprint")
        if text.attrib.get("text-anchor") not in {"start", "middle", "end"}:
            raise SvgError(f"{group_id} text anchor is invalid")
        if text.attrib.get("font-style") not in {"normal", "italic"}:
            raise SvgError(f"{group_id} text font-style is invalid")
        weight = text.attrib.get("font-weight", "")
        if weight not in {"normal", "bold", "bolder", "lighter"}:
            numeric_weight = finite(weight, f"{group_id} text font-weight")
            if not 1 <= numeric_weight <= 1000:
                raise SvgError(f"{group_id} text font-weight is invalid")
        font_family_value(
            text.attrib.get("font-family"), f"{group_id} text font-family"
        )
        visible_color(text.attrib.get("fill"), f"{group_id} text fill")
        if "opacity" in text.attrib:
            text_opacity = finite(text.attrib["opacity"], f"{group_id} text opacity")
            if not 0 < text_opacity <= 1:
                raise SvgError(f"{group_id} text opacity is invalid")
        if "letter-spacing" in text.attrib:
            spacing = finite(
                text.attrib["letter-spacing"], f"{group_id} text letter-spacing"
            )
            if abs(spacing) > 2 * font_size:
                raise SvgError(f"{group_id} text letter-spacing is invalid")
        text_count += 1

    return {
        "verdict": "PASS",
        "svg": svg_path.name,
        "svg_sha256": hashlib.sha256(payload).hexdigest(),
        "viewBox": [0, 0, width, height],
        "png_dimensions": list(png_size),
        "counts": {
            "image": 1,
            "editable_text_layer": 1,
            "label_groups": len(label_groups),
            "rect": rect_count,
            "backplate": backplate_count,
            "collision_footprint": collision_count,
            "text": text_count,
        },
        "errors": [],
        "warnings": [],
    }


def write_report(path: Path, result: dict[str, object], replace: bool) -> None:
    payload = (json.dumps(result, indent=2, ensure_ascii=False) + "\n").encode()
    path.parent.mkdir(parents=True, exist_ok=True)
    if not replace:
        with path.open("xb") as handle:
            handle.write(payload)
        return
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("svg", type=Path)
    parser.add_argument("--json", action="store_true", help="Emit JSON")
    parser.add_argument("--report", type=Path, help="Write a JSON validation report")
    parser.add_argument("--replace-report", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        svg_path = args.svg.resolve(strict=True)
        result = validate(svg_path)
    except (OSError, ET.ParseError, SvgError) as exc:
        result = {
            "verdict": "FAIL",
            "svg": str(args.svg),
            "counts": {},
            "errors": [str(exc)],
            "warnings": [],
        }
    if args.report:
        try:
            write_report(args.report.resolve(), result, args.replace_report)
        except OSError as exc:
            print(f"ERROR: cannot write report: {exc}", file=sys.stderr)
            return 2
    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print(
            f"{result['verdict']}: images={result['counts'].get('image', 0)}, "
            f"text={result['counts'].get('text', 0)}, "
            f"rect={result['counts'].get('rect', 0)}"
        )
        for message in result["errors"]:
            print(f"ERROR: {message}")
        for message in result["warnings"]:
            print(f"WARNING: {message}")
    return 0 if result["verdict"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
