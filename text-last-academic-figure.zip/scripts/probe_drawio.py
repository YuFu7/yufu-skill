#!/usr/bin/env python3
"""Read-only Draw.io CDP discovery. Does not modify documents or configure MCP."""

import argparse
import ipaddress
import json
import sys
import urllib.request
from urllib.parse import urlsplit


def loopback_url(url):
    parts = urlsplit(url)
    host = parts.hostname or ""
    if parts.scheme != "http" or parts.username or parts.password:
        raise ValueError("use a plain HTTP loopback endpoint")
    if host != "localhost" and not ipaddress.ip_address(host).is_loopback:
        raise ValueError("only loopback CDP endpoints are supported")
    return url.rstrip("/")


def discover(endpoint, timeout=5):
    endpoint = loopback_url(endpoint)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(endpoint + "/json/list", timeout=timeout) as response:
        targets = json.load(response)
    pages = [{"id": p.get("id"), "title": p.get("title"),
              "websocket_available": bool(p.get("webSocketDebuggerUrl"))}
             for p in targets if p.get("type") == "page"
             and ("draw.io" in (p.get("url", "") + p.get("title", "")).lower()
                  or "diagrams.net" in p.get("url", "").lower())]
    return {"endpoint": endpoint, "cdp_reachable": True, "drawio_pages": pages,
            "graph_ready": "not_checked", "live_tools": "not_checked",
            "document_modified": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--endpoint", default="http://127.0.0.1:9333")
    args = parser.parse_args()
    try:
        result = discover(args.endpoint)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["drawio_pages"] else 1
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(json.dumps({"cdp_reachable": False, "error": str(error)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())
