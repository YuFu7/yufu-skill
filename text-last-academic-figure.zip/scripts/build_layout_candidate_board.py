#!/usr/bin/env python3
"""Build an auditable SVG board and JSON manifest for PNG layout candidates."""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import math
import os
import re
import sys
import tempfile
from pathlib import Path
from xml.etree import ElementTree as ET

from text_last_png import PngError, validate_png_path


SVG_NS = "http://www.w3.org/2000/svg"
ET.register_namespace("", SVG_NS)
CANDIDATE_ID = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,31}$")
MIN_CANDIDATES = 2
MAX_CANDIDATES = 8
MAX_BOARD_PIXELS = 200_000_000
MAX_TOTAL_INPUT_BYTES = 512 * 1024 * 1024


class BoardError(ValueError):
    """Raised when layout candidates violate the comparison contract."""


def parse_candidate(raw: str) -> tuple[str, Path]:
    if "=" not in raw:
        raise BoardError("--candidate must use ID=PATH syntax")
    candidate_id, path_text = raw.split("=", 1)
    if not CANDIDATE_ID.fullmatch(candidate_id):
        raise BoardError(f"invalid candidate id: {candidate_id!r}")
    if not path_text:
        raise BoardError(f"candidate {candidate_id} has an empty path")
    return candidate_id, Path(path_text)


def atomic_write(path: Path, payload: bytes, replace: bool) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not replace:
        with path.open("xb") as handle:
            handle.write(payload)
        return
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def resolve_candidates(raw_items: list[str]) -> list[dict[str, object]]:
    if not MIN_CANDIDATES <= len(raw_items) <= MAX_CANDIDATES:
        raise BoardError(
            f"candidate count must be between {MIN_CANDIDATES} and {MAX_CANDIDATES}"
        )
    records: list[dict[str, object]] = []
    seen_ids: set[str] = set()
    expected_size: tuple[int, int] | None = None
    total_input_bytes = 0
    for raw in raw_items:
        candidate_id, raw_path = parse_candidate(raw)
        if candidate_id in seen_ids:
            raise BoardError(f"duplicate candidate id: {candidate_id}")
        seen_ids.add(candidate_id)
        path = raw_path.resolve(strict=True)
        if path.suffix.lower() != ".png":
            raise BoardError(f"candidate {candidate_id} must be a PNG")
        size = validate_png_path(path)
        if expected_size is None:
            expected_size = size
        elif size != expected_size:
            raise BoardError(
                f"candidate {candidate_id} dimensions {size[0]}x{size[1]} do not "
                f"match {expected_size[0]}x{expected_size[1]}"
            )
        payload = path.read_bytes()
        total_input_bytes += len(payload)
        if total_input_bytes > MAX_TOTAL_INPUT_BYTES:
            raise BoardError("candidate payloads exceed the total input safety limit")
        records.append(
            {
                "id": candidate_id,
                "path": str(path),
                "width": size[0],
                "height": size[1],
                "sha256": hashlib.sha256(payload).hexdigest(),
                "payload": payload,
            }
        )
    return records


def build_board(records: list[dict[str, object]], columns: int) -> bytes:
    if not 1 <= columns <= len(records):
        raise BoardError("--columns must be between one and the candidate count")
    width = int(records[0]["width"])
    height = int(records[0]["height"])
    rows = math.ceil(len(records) / columns)
    gap = max(16, round(width * 0.025))
    header = max(42, round(height * 0.065))
    board_width = columns * width + (columns + 1) * gap
    board_height = rows * (height + header) + (rows + 1) * gap
    if board_width * board_height > MAX_BOARD_PIXELS:
        raise BoardError("candidate board exceeds the canvas safety limit")

    root = ET.Element(
        f"{{{SVG_NS}}}svg",
        {
            "width": str(board_width),
            "height": str(board_height),
            "viewBox": f"0 0 {board_width} {board_height}",
            "role": "img",
            "aria-labelledby": "title desc",
        },
    )
    title = ET.SubElement(root, f"{{{SVG_NS}}}title", {"id": "title"})
    title.text = "Text-free pixel-layout candidate board"
    desc = ET.SubElement(root, f"{{{SVG_NS}}}desc", {"id": "desc"})
    desc.text = "Candidate identifiers appear only in audit-board margins."
    ET.SubElement(
        root,
        f"{{{SVG_NS}}}rect",
        {
            "x": "0",
            "y": "0",
            "width": str(board_width),
            "height": str(board_height),
            "fill": "#F4F6F8",
        },
    )
    for index, record in enumerate(records):
        row, column = divmod(index, columns)
        x = gap + column * (width + gap)
        y = gap + row * (height + header + gap)
        group = ET.SubElement(root, f"{{{SVG_NS}}}g", {"id": f"candidate-{record['id']}"})
        ET.SubElement(
            group,
            f"{{{SVG_NS}}}rect",
            {
                "x": str(x),
                "y": str(y),
                "width": str(width),
                "height": str(height + header),
                "rx": str(max(8, gap // 2)),
                "fill": "#FFFFFF",
                "stroke": "#B8C2CC",
                "stroke-width": "2",
            },
        )
        label = ET.SubElement(
            group,
            f"{{{SVG_NS}}}text",
            {
                "x": str(x + gap),
                "y": str(y + round(header * 0.68)),
                "font-family": "Nimbus Sans, Arial, sans-serif",
                "font-size": str(max(22, round(header * 0.42))),
                "font-weight": "700",
                "fill": "#202832",
            },
        )
        label.text = str(record["id"])
        encoded = base64.b64encode(record["payload"]).decode("ascii")
        ET.SubElement(
            group,
            f"{{{SVG_NS}}}image",
            {
                "x": str(x),
                "y": str(y + header),
                "width": str(width),
                "height": str(height),
                "preserveAspectRatio": "xMidYMid meet",
                "href": f"data:image/png;base64,{encoded}",
            },
        )
    ET.indent(root, space="  ")
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", action="append", required=True, help="ID=PATH")
    parser.add_argument("--output", required=True, type=Path, help="Board SVG")
    parser.add_argument("--manifest", required=True, type=Path, help="Manifest JSON")
    parser.add_argument("--columns", type=int, default=2)
    parser.add_argument("--replace", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        output = args.output.resolve()
        manifest_path = args.manifest.resolve()
        if output.suffix.lower() != ".svg":
            raise BoardError("--output must end in .svg")
        if manifest_path.suffix.lower() != ".json":
            raise BoardError("--manifest must end in .json")
        if output == manifest_path:
            raise BoardError("board and manifest paths must differ")
        if not args.replace and (output.exists() or manifest_path.exists()):
            raise BoardError("output or manifest already exists")
        records = resolve_candidates(args.candidate)
        board = build_board(records, args.columns)
        manifest = {
            "schema": "text-last-layout-candidates-v1",
            "candidate_count": len(records),
            "common_dimensions": [records[0]["width"], records[0]["height"]],
            "columns": args.columns,
            "candidates": [
                {key: record[key] for key in ("id", "path", "width", "height", "sha256")}
                for record in records
            ],
            "board_sha256": hashlib.sha256(board).hexdigest(),
        }
        manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode("utf-8")
        atomic_write(output, board, args.replace)
        try:
            atomic_write(manifest_path, manifest_bytes, args.replace)
        except Exception:
            if not args.replace and output.exists():
                output.unlink()
            raise
    except (OSError, PngError, BoardError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print(
        f"OK: wrote {output} and {manifest_path} for {len(records)} candidates"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
