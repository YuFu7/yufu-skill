#!/usr/bin/env python3
"""Compose one validated PNG substrate with a canonical editable SVG text layer."""

from __future__ import annotations

import argparse
import base64
import json
import math
import os
import re
import sys
import tempfile
import unicodedata
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from text_last_png import PngError, validate_png_path


SVG_NS = "http://www.w3.org/2000/svg"
ET.register_namespace("", SVG_NS)
XML_ID = re.compile(r"^[A-Za-z_][A-Za-z0-9_.-]{0,127}$")
COLOR = re.compile(r"^#(?:[0-9A-Fa-f]{3,4}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$")
NAMED_COLORS = {"black", "white", "transparent", "none"}
TOP_KEYS = {"canvas", "title", "description", "font_family", "labels"}
CANVAS_KEYS = {"width", "height", "physical_width_in"}
LABEL_KEYS = {
    "id",
    "text",
    "x",
    "y",
    "anchor",
    "font_size",
    "font_weight",
    "font_style",
    "fill",
    "letter_spacing",
    "opacity",
    "backplate",
    "collision_box",
}
BOX_KEYS = {"x", "y", "width", "height"}
PLATE_KEYS = BOX_KEYS | {
    "rx",
    "fill",
    "fill_opacity",
    "stroke",
    "stroke_width",
}


class SpecError(ValueError):
    """Raised when an overlay specification violates a hard gate."""


def reject_unknown(mapping: dict[str, Any], allowed: set[str], field: str) -> None:
    unknown = set(mapping) - allowed
    if unknown:
        raise SpecError(f"{field} has unexpected fields: {sorted(unknown)}")


def finite_number(value: Any, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise SpecError(f"{field} must be a number")
    number = float(value)
    if not math.isfinite(number):
        raise SpecError(f"{field} must be finite")
    return number


def positive_number(value: Any, field: str) -> float:
    number = finite_number(value, field)
    if number <= 0:
        raise SpecError(f"{field} must be positive")
    return number


def opacity(value: Any, field: str) -> float:
    number = finite_number(value, field)
    if not 0 <= number <= 1:
        raise SpecError(f"{field} must be in [0, 1]")
    return number


def color(value: Any, field: str) -> str:
    if not isinstance(value, str):
        raise SpecError(f"{field} must be a color string")
    if not COLOR.fullmatch(value) and value.lower() not in NAMED_COLORS:
        raise SpecError(f"{field} must be a hex color or an allowed named color")
    return value


def visible_color(value: Any, field: str) -> str:
    result = color(value, field)
    lowered = result.lower()
    if lowered in {"none", "transparent"}:
        raise SpecError(f"{field} must be visible")
    if lowered.startswith("#"):
        alpha = None
        if len(lowered) == 5:
            alpha = lowered[-1]
        elif len(lowered) == 9:
            alpha = lowered[-2:]
        if alpha is not None and int(alpha, 16) == 0:
            raise SpecError(f"{field} has zero alpha")
    return result


def font_family(value: Any, field: str) -> str:
    result = clean_text(value, field, 256)
    families = result.split(",")
    if not families or any(not item.strip() for item in families):
        raise SpecError(f"{field} contains an empty font family")
    for item in families:
        family = item.strip()
        if family[:1] in {"'", '"'}:
            if len(family) < 3 or family[-1] != family[0]:
                raise SpecError(f"{field} contains an invalid quoted family")
            family = family[1:-1]
        if not family or not any(
            unicodedata.category(char)[0] in {"L", "N"} for char in family
        ):
            raise SpecError(f"{field} contains a family without letters or numbers")
        if any(
            not (
                unicodedata.category(char)[0] in {"L", "N"}
                or char in {" ", "-", "_", "."}
            )
            for char in family
        ):
            raise SpecError(f"{field} contains unsupported family syntax")
    return result


def clean_text(value: Any, field: str, maximum: int) -> str:
    if not isinstance(value, str) or not value.strip():
        raise SpecError(f"{field} must be non-empty text")
    if len(value) > maximum or any(
        unicodedata.category(char)[0] == "C" for char in value
    ):
        raise SpecError(f"{field} is too long or contains control/format characters")
    if "\n" in value or "\r" in value:
        raise SpecError(f"{field} must be a single line")
    if not any(
        unicodedata.category(char)[0] in {"L", "N", "P", "S"} for char in value
    ):
        raise SpecError(f"{field} has no renderable base character")
    return value


def rectangles_intersect(a: dict[str, float], b: dict[str, float]) -> bool:
    return not (
        a["x"] + a["width"] <= b["x"]
        or b["x"] + b["width"] <= a["x"]
        or a["y"] + a["height"] <= b["y"]
        or b["y"] + b["height"] <= a["y"]
    )


def normalize_box(
    box: Any, field: str, canvas_width: float, canvas_height: float
) -> dict[str, float]:
    if not isinstance(box, dict):
        raise SpecError(f"{field} must be an object")
    allowed = PLATE_KEYS if field.endswith("backplate") else BOX_KEYS
    reject_unknown(box, allowed, field)
    normalized = {
        "x": finite_number(box.get("x"), f"{field}.x"),
        "y": finite_number(box.get("y"), f"{field}.y"),
        "width": positive_number(box.get("width"), f"{field}.width"),
        "height": positive_number(box.get("height"), f"{field}.height"),
    }
    if (
        normalized["x"] < 0
        or normalized["y"] < 0
        or normalized["x"] + normalized["width"] > canvas_width
        or normalized["y"] + normalized["height"] > canvas_height
    ):
        raise SpecError(f"{field} is outside the canvas")
    return normalized


def validate_spec(spec: dict[str, Any], image_size: tuple[int, int]) -> dict[str, Any]:
    reject_unknown(spec, TOP_KEYS, "spec")
    canvas = spec.get("canvas")
    if not isinstance(canvas, dict):
        raise SpecError("canvas must be an object")
    reject_unknown(canvas, CANVAS_KEYS, "canvas")
    width = positive_number(canvas.get("width"), "canvas.width")
    height = positive_number(canvas.get("height"), "canvas.height")
    if not width.is_integer() or not height.is_integer():
        raise SpecError("canvas width and height must be integers")
    if image_size != (int(width), int(height)):
        raise SpecError(
            f"PNG dimensions {image_size[0]}x{image_size[1]} do not match "
            f"canvas {int(width)}x{int(height)}"
        )
    if "physical_width_in" in canvas:
        positive_number(canvas["physical_width_in"], "canvas.physical_width_in")
    if "title" in spec:
        clean_text(spec["title"], "title", 256)
    if "description" in spec:
        clean_text(spec["description"], "description", 1024)
    if "font_family" in spec:
        font_family(spec["font_family"], "font_family")

    labels = spec.get("labels")
    if not isinstance(labels, list) or not labels:
        raise SpecError("labels must be a non-empty array")

    seen_ids: set[str] = set()
    footprints: list[tuple[str, dict[str, float]]] = []
    for index, label in enumerate(labels):
        prefix = f"labels[{index}]"
        if not isinstance(label, dict):
            raise SpecError(f"{prefix} must be an object")
        reject_unknown(label, LABEL_KEYS, prefix)
        label_id = label.get("id")
        if not isinstance(label_id, str) or not XML_ID.fullmatch(label_id):
            raise SpecError(f"{prefix}.id must be a unique XML-safe identifier")
        if label_id in seen_ids:
            raise SpecError(f"duplicate label id: {label_id}")
        seen_ids.add(label_id)
        clean_text(label.get("text"), f"{prefix}.text", 256)
        x = finite_number(label.get("x"), f"{prefix}.x")
        y = finite_number(label.get("y"), f"{prefix}.y")
        if not 0 <= x <= width or not 0 <= y <= height:
            raise SpecError(f"{prefix} anchor is outside the canvas")
        font_size = positive_number(label.get("font_size"), f"{prefix}.font_size")
        if font_size > min(width, height) / 3:
            raise SpecError(f"{prefix}.font_size is implausibly large")
        anchor = label.get("anchor", "start")
        if anchor not in {"start", "middle", "end"}:
            raise SpecError(f"{prefix}.anchor must be start, middle, or end")
        if label.get("font_style", "normal") not in {"normal", "italic"}:
            raise SpecError(f"{prefix}.font_style must be normal or italic")
        weight = label.get("font_weight", 700)
        if isinstance(weight, bool) or not (
            (isinstance(weight, (int, float)) and 1 <= float(weight) <= 1000)
            or weight in {"normal", "bold", "bolder", "lighter"}
        ):
            raise SpecError(f"{prefix}.font_weight is invalid")
        if "fill" in label:
            visible_color(label["fill"], f"{prefix}.fill")
        if "opacity" in label:
            if opacity(label["opacity"], f"{prefix}.opacity") == 0:
                raise SpecError(f"{prefix}.opacity must be visible")
        if "letter_spacing" in label:
            spacing = finite_number(label["letter_spacing"], f"{prefix}.letter_spacing")
            if abs(spacing) > 2 * font_size:
                raise SpecError(f"{prefix}.letter_spacing is implausibly large")

        has_plate = label.get("backplate") is not None
        has_collision = label.get("collision_box") is not None
        if has_plate == has_collision:
            raise SpecError(
                f"{prefix} must provide exactly one of backplate or collision_box"
            )
        field = f"{prefix}.backplate" if has_plate else f"{prefix}.collision_box"
        raw_box = label["backplate"] if has_plate else label["collision_box"]
        normalized = normalize_box(raw_box, field, width, height)
        if normalized["width"] > 0.6 * width or normalized["height"] > 0.2 * height:
            raise SpecError(f"{field} is not compact")
        if not (
            normalized["x"] <= x <= normalized["x"] + normalized["width"]
            and normalized["y"] <= y <= normalized["y"] + normalized["height"]
        ):
            raise SpecError(f"{prefix} anchor is outside its footprint")
        if has_plate:
            plate = label["backplate"]
            rx = finite_number(plate.get("rx", 10), f"{prefix}.backplate.rx")
            if not 0 <= rx <= min(normalized["width"], normalized["height"]) / 2:
                raise SpecError(f"{prefix}.backplate.rx is invalid")
            visible_color(plate.get("fill", "#FFFFFF"), f"{prefix}.backplate.fill")
            if opacity(
                plate.get("fill_opacity", 0.94),
                f"{prefix}.backplate.fill_opacity",
            ) == 0:
                raise SpecError(f"{prefix}.backplate.fill_opacity must be visible")
            color(plate.get("stroke", "#D9E0E7"), f"{prefix}.backplate.stroke")
            stroke_width = finite_number(
                plate.get("stroke_width", 1.5),
                f"{prefix}.backplate.stroke_width",
            )
            if not 0 <= stroke_width <= 20:
                raise SpecError(f"{prefix}.backplate.stroke_width is invalid")
        for other_id, other in footprints:
            if rectangles_intersect(normalized, other):
                raise SpecError(f"label footprints overlap: {label_id} intersects {other_id}")
        footprints.append((label_id, normalized))
    return spec


def svg_length(value: Any) -> str:
    number = float(value)
    if number.is_integer():
        return str(int(number))
    return f"{number:.6g}"


def linked_href(image: Path, output: Path, inline: bool) -> str:
    if inline:
        payload = base64.b64encode(image.read_bytes()).decode("ascii")
        return f"data:image/png;base64,{payload}"
    try:
        relative = image.relative_to(output.parent)
    except ValueError as exc:
        raise SpecError(
            "linked PNG must be inside the SVG output directory; use --inline "
            "or copy the Stage 2 PNG beside the successor SVG"
        ) from exc
    if not relative.parts or ".." in relative.parts:
        raise SpecError("linked PNG path must not traverse directories")
    return relative.as_posix()


def build_svg(
    image: Path, output: Path, spec: dict[str, Any], inline: bool
) -> ET.ElementTree:
    canvas = spec["canvas"]
    width = int(canvas["width"])
    height = int(canvas["height"])
    physical_width = canvas.get("physical_width_in")
    if physical_width is None:
        svg_width = str(width)
        svg_height = str(height)
    else:
        physical_width = float(physical_width)
        svg_width = f"{physical_width:.6g}in"
        svg_height = f"{physical_width * height / width:.6g}in"

    root = ET.Element(
        f"{{{SVG_NS}}}svg",
        {
            "width": svg_width,
            "height": svg_height,
            "viewBox": f"0 0 {width} {height}",
            "role": "img",
            "aria-labelledby": "title desc",
        },
    )
    title = ET.SubElement(root, f"{{{SVG_NS}}}title", {"id": "title"})
    title.text = str(spec.get("title", "Text-last academic figure"))
    desc = ET.SubElement(root, f"{{{SVG_NS}}}desc", {"id": "desc"})
    desc.text = str(
        spec.get(
            "description",
            "One validated PNG substrate with a canonical editable vector text layer.",
        )
    )
    ET.SubElement(
        root,
        f"{{{SVG_NS}}}image",
        {
            "id": "text-free-substrate",
            "x": "0",
            "y": "0",
            "width": str(width),
            "height": str(height),
            "preserveAspectRatio": "xMidYMid meet",
            "href": linked_href(image, output, inline),
        },
    )

    group = ET.SubElement(root, f"{{{SVG_NS}}}g", {"id": "editable-text-layer"})
    font_family = str(
        spec.get(
            "font_family", "Nimbus Sans, Helvetica Neue, Arial, sans-serif"
        )
    )
    for label in spec["labels"]:
        label_group = ET.SubElement(
            group, f"{{{SVG_NS}}}g", {"id": f"label-{label['id']}"}
        )
        plate = label.get("backplate")
        footprint = plate if plate is not None else label["collision_box"]
        if plate is not None:
            rect_attrs = {
                "data-role": "backplate",
                "x": svg_length(plate["x"]),
                "y": svg_length(plate["y"]),
                "width": svg_length(plate["width"]),
                "height": svg_length(plate["height"]),
                "rx": svg_length(plate.get("rx", 10)),
                "fill": str(plate.get("fill", "#FFFFFF")),
                "fill-opacity": svg_length(plate.get("fill_opacity", 0.94)),
                "stroke": str(plate.get("stroke", "#D9E0E7")),
                "stroke-width": svg_length(plate.get("stroke_width", 1.5)),
            }
        else:
            rect_attrs = {
                "data-role": "collision-footprint",
                "x": svg_length(footprint["x"]),
                "y": svg_length(footprint["y"]),
                "width": svg_length(footprint["width"]),
                "height": svg_length(footprint["height"]),
                "rx": "0",
                "fill": "none",
                "fill-opacity": "0",
                "stroke": "none",
                "stroke-width": "0",
            }
        ET.SubElement(
            label_group,
            f"{{{SVG_NS}}}rect",
            rect_attrs,
        )
        text_attrs = {
            "x": svg_length(label["x"]),
            "y": svg_length(label["y"]),
            "text-anchor": str(label.get("anchor", "start")),
            "font-family": font_family,
            "font-size": svg_length(label["font_size"]),
            "font-weight": str(label.get("font_weight", 700)),
            "font-style": str(label.get("font_style", "normal")),
            "fill": str(label.get("fill", "#202832")),
        }
        if "letter_spacing" in label:
            text_attrs["letter-spacing"] = svg_length(label["letter_spacing"])
        if "opacity" in label:
            text_attrs["opacity"] = svg_length(label["opacity"])
        text = ET.SubElement(label_group, f"{{{SVG_NS}}}text", text_attrs)
        text.text = label["text"]
    ET.indent(root, space="  ")
    return ET.ElementTree(root)


def write_tree(tree: ET.ElementTree, output: Path, replace: bool) -> None:
    payload = ET.tostring(tree.getroot(), encoding="utf-8", xml_declaration=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    if not replace:
        with output.open("xb") as handle:
            handle.write(payload)
        return
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{output.name}.", suffix=".tmp", dir=output.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, output)
    finally:
        if temporary.exists():
            temporary.unlink()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", required=True, type=Path, help="Stage 2 PNG")
    parser.add_argument("--spec", required=True, type=Path, help="Overlay JSON")
    parser.add_argument("--output", required=True, type=Path, help="Successor SVG")
    parser.add_argument("--inline", action="store_true", help="Embed the PNG")
    parser.add_argument(
        "--replace",
        action="store_true",
        help="Explicitly replace output; never use for frozen or promoted assets",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        image = args.image.resolve(strict=True)
        spec_path = args.spec.resolve(strict=True)
        output = args.output.resolve()
        if image.suffix.lower() != ".png":
            raise SpecError("--image must end in .png")
        if output.suffix.lower() != ".svg":
            raise SpecError("--output must end in .svg")
        if output.exists() and not args.replace:
            raise SpecError(f"output already exists: {output}")
        spec = json.loads(spec_path.read_text(encoding="utf-8"))
        if not isinstance(spec, dict):
            raise SpecError("spec root must be a JSON object")
        validate_spec(spec, validate_png_path(image))
        tree = build_svg(image, output, spec, args.inline)
        write_tree(tree, output, args.replace)
    except (OSError, json.JSONDecodeError, PngError, SpecError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print(
        f"OK: wrote {output} with 1 validated PNG, "
        f"{len(spec['labels'])} editable labels, inline={args.inline}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
