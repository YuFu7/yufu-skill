#!/usr/bin/env python3
"""Strict, dependency-free PNG validation for text-last figure substrates."""

from __future__ import annotations

import struct
import zlib
from pathlib import Path


PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
CHANNELS = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}
LEGAL_BIT_DEPTHS = {
    0: {1, 2, 4, 8, 16},
    2: {8, 16},
    3: {1, 2, 4, 8},
    4: {8, 16},
    6: {8, 16},
}
KNOWN_CRITICAL = {b"IHDR", b"PLTE", b"IDAT", b"IEND"}
MAX_PIXELS = 100_000_000
MAX_DECOMPRESSED_BYTES = 512 * 1024 * 1024
MAX_INPUT_BYTES = 256 * 1024 * 1024


class PngError(ValueError):
    """Raised when a PNG fails the substrate integrity contract."""


def validate_png_bytes(payload: bytes) -> tuple[int, int]:
    if len(payload) > MAX_INPUT_BYTES:
        raise PngError("PNG input exceeds the compressed payload limit")
    if not payload.startswith(PNG_SIGNATURE):
        raise PngError("invalid PNG signature")
    position = len(PNG_SIGNATURE)
    chunks: list[tuple[bytes, bytes]] = []
    seen_iend = False
    while position < len(payload):
        if len(payload) - position < 12:
            raise PngError("truncated PNG chunk header")
        length = struct.unpack(">I", payload[position : position + 4])[0]
        chunk_type = payload[position + 4 : position + 8]
        if (
            len(chunk_type) != 4
            or any(not (65 <= value <= 90 or 97 <= value <= 122) for value in chunk_type)
            or not 65 <= chunk_type[2] <= 90
        ):
            raise PngError(f"illegal PNG chunk name {chunk_type!r}")
        end = position + 12 + length
        if end > len(payload):
            raise PngError("truncated PNG chunk payload")
        chunk_data = payload[position + 8 : position + 8 + length]
        expected_crc = struct.unpack(
            ">I", payload[position + 8 + length : end]
        )[0]
        actual_crc = zlib.crc32(chunk_type)
        actual_crc = zlib.crc32(chunk_data, actual_crc) & 0xFFFFFFFF
        if actual_crc != expected_crc:
            raise PngError(f"PNG CRC mismatch in {chunk_type!r}")
        if chunk_type[:1].isupper() and chunk_type not in KNOWN_CRITICAL:
            raise PngError(f"unknown critical PNG chunk {chunk_type!r}")
        chunks.append((chunk_type, chunk_data))
        position = end
        if chunk_type == b"IEND":
            seen_iend = True
            break
    if not seen_iend:
        raise PngError("PNG has no IEND chunk")
    if position != len(payload):
        raise PngError("trailing bytes after PNG IEND")
    if not chunks or chunks[0][0] != b"IHDR":
        raise PngError("IHDR must be the first PNG chunk")
    if chunks[-1][0] != b"IEND" or chunks[-1][1]:
        raise PngError("IEND must be empty and last")
    chunk_types = [item[0] for item in chunks]
    if chunk_types.count(b"IHDR") != 1:
        raise PngError("PNG must contain exactly one IHDR")
    if chunk_types.count(b"IEND") != 1:
        raise PngError("PNG must contain exactly one IEND")
    if chunk_types.count(b"PLTE") > 1:
        raise PngError("PNG must contain at most one PLTE")
    if len(chunks[0][1]) != 13:
        raise PngError("IHDR must contain 13 bytes")

    width, height, bit_depth, color_type, compression, filter_method, interlace = (
        struct.unpack(">IIBBBBB", chunks[0][1])
    )
    if width <= 0 or height <= 0:
        raise PngError("PNG dimensions must be positive")
    if width * height > MAX_PIXELS:
        raise PngError("PNG exceeds the substrate pixel limit")
    if color_type not in LEGAL_BIT_DEPTHS or bit_depth not in LEGAL_BIT_DEPTHS[color_type]:
        raise PngError("illegal PNG bit-depth/color-type combination")
    if compression != 0 or filter_method != 0:
        raise PngError("unsupported PNG compression or filter method")
    if interlace != 0:
        raise PngError("interlaced PNG substrates are not accepted")

    idat_indices = [index for index, item in enumerate(chunks) if item[0] == b"IDAT"]
    if not idat_indices:
        raise PngError("PNG has no IDAT data")
    if idat_indices != list(range(idat_indices[0], idat_indices[-1] + 1)):
        raise PngError("PNG IDAT chunks must be consecutive")
    plte_indices = [index for index, item in enumerate(chunks) if item[0] == b"PLTE"]
    if plte_indices and plte_indices[0] > idat_indices[0]:
        raise PngError("PLTE must appear before IDAT")
    if color_type in {0, 4} and plte_indices:
        raise PngError("grayscale PNG must not contain PLTE")
    if color_type == 3 and len(plte_indices) != 1:
        raise PngError("indexed PNG requires exactly one PLTE before IDAT")
    if plte_indices:
        palette = chunks[plte_indices[0]][1]
        if not palette or len(palette) % 3 or len(palette) > 768:
            raise PngError("PLTE length must be a nonzero multiple of 3 up to 768")
        if color_type == 3 and len(palette) // 3 > 2**bit_depth:
            raise PngError("indexed PNG PLTE has too many entries for its bit depth")

    bits_per_pixel = CHANNELS[color_type] * bit_depth
    row_bytes = (width * bits_per_pixel + 7) // 8
    expected_size = height * (1 + row_bytes)
    if expected_size > MAX_DECOMPRESSED_BYTES:
        raise PngError("PNG decompressed payload exceeds the safety limit")
    compressed = b"".join(chunks[index][1] for index in idat_indices)
    if not compressed:
        raise PngError("PNG IDAT payload is empty")
    try:
        decompressor = zlib.decompressobj()
        raw = decompressor.decompress(compressed, MAX_DECOMPRESSED_BYTES + 1)
        if len(raw) > MAX_DECOMPRESSED_BYTES:
            raise PngError("PNG decompressed payload exceeds the safety limit")
        raw += decompressor.flush()
    except zlib.error as exc:
        raise PngError(f"PNG IDAT zlib decode failed: {exc}") from exc
    if not decompressor.eof or decompressor.unused_data or decompressor.unconsumed_tail:
        raise PngError("PNG IDAT stream did not terminate cleanly")
    if len(raw) != expected_size:
        raise PngError(
            f"PNG scanline size mismatch: expected {expected_size}, got {len(raw)}"
        )
    for row in range(height):
        filter_byte = raw[row * (row_bytes + 1)]
        if filter_byte > 4:
            raise PngError(f"invalid PNG filter byte {filter_byte} on row {row}")
    return width, height


def validate_png_path(path: Path) -> tuple[int, int]:
    try:
        payload = path.read_bytes()
    except OSError as exc:
        raise PngError(f"cannot read PNG: {exc}") from exc
    return validate_png_bytes(payload)
