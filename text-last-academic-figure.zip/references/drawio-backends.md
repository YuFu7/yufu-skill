# Draw.io 后端与 WSL2

## 当前能力优先

查看当前可调用工具，不把说明中的名称当作已安装功能。Scientific Illustrator v1.5.4 的 live 工具以 `drawio_live_` 开头，但不同集成可能添加命名空间或改变参数；先读真实 schema。

有该插件时，典型路径为 capabilities/status/inspect → add_shape/add_image/add_edge 或 draw_sequence → screenshot/inspect → 保存母版与导出。以实际返回确认图模型、目标页面和输出路径；不要硬编码旧 cell ID。按模块批量绘制，必要时使用 align/distribute/group/update 能力，不为每个对象暂停。

传入图片时如工具要求 raster_reason、source_is_tightly_cropped、atomic_raster_unit、contains_reconstructable_content 等说明，依据真实资产填写；不能为了通过审查伪造“没有文字/没有结构”。端点显式传 source/target 与端口。保存现稿副本后才做修改，失败时保留可恢复成果。

没有 live 工具且未强制实时：使用 build_drawio.py。端口通了不会自动安装或注册 MCP。安装插件、修改 Codex 配置是另一个实际环境操作，不能在绘图中默默执行。

## WSL2 Codex CLI + Windows Draw.io Desktop

优先连接已经由用户开启调试端口的 Windows 实例，不在 WSL 中重复启动 Linux Draw.io。现有配置可先做只读探测：

```bash
python3 /home/minxi/.codex/skills/text-last-academic-figure/scripts/probe_drawio.py
```

默认仅探测 `http://127.0.0.1:9333/json/list`，不改图、不发绘制命令。返回页面列表仅证明 CDP 可达；graph_ready/live_tools 为 not_checked。连接报错时区分沙箱网络权限与宿主机监听问题：在运行环境允许的审批机制下做同一最小只读复测，不关闭防火墙或扩大绑定地址。

9333 是 Electron 的 CDP 调试端口，**不是 MCP HTTP 服务**，不能直接填成 Codex 的 MCP URL。STDIO 插件通过 CDP 操作 Draw.io。调试端口可控制应用，应只保留本机可达。镜像网络可用 localhost；其他 WSL 网络模式需实际核对，不能假定宿主机 IP。

本机此前实测过 Windows Draw.io 经 localhost 可达且图模型可读；这是一次历史连接验证，不替代每次选定目标文档。应用安装位置和 WSL 发行版名都应运行时确认，不能从示例硬编码。

## 文件与导出

本地 .drawio 可经 Windows 文件选择器打开 WSL 路径。调用 Windows 程序时，将**输入和输出**路径用 `wslpath -w` 转换，并使用参数数组或正确引用；单独指定 DRAWIO_PATH 不会转换 Linux 路径。不要把 /home/... 原样传给 Windows 导出进程。

先检查实际 Desktop CLI 的 `--help`。支持相应选项时，基本形式为：

```text
draw.io.exe --export --format svg --output <Windows输出路径> <Windows输入.drawio路径>
```

文件导出不需要 CDP；不要为导出关闭用户已有窗口。实际安装版本、WSL 互操作、UNC 路径和写权限都可能影响导出；失败时保留母版并如实说明未导出，不改用远程服务上传用户资料。

本次本机 Draw.io 31.4.4 已验证 Windows CLI 经 WSL UNC 路径导出独立示例 PNG。该版本支持 `--size page` 保留完整页面和 `--theme light` 固定白底；其他版本先查帮助。CLI 偶有缓存锁警告，需结合退出码、输出文件和实际预览判断，不能仅凭警告认定导出失败。

实际打开导出的 SVG/PDF 检查字体、透明素材、裁切和箭头。HTML/foreignObject 或公式可能导致不同查看器表现不同；必要时使用纯文本原生标签，或明确交付兼容 PDF 并保留 .drawio。

参考：[Draw.io 官方生成与文件格式](https://www.drawio.com/docs/reference/diagram-generation/)、[官方导出说明](https://www.drawio.com/docs/manual/export/export-diagram/)、[Scientific Illustrator](https://github.com/icebird1998/scientific-illustrator)。官方在线 MCP 与本机 Electron CDP 是不同后端；本 skill 不依赖上传到在线编辑器。
