# File 后端的 scene 输入

此轻量输入只用于确定性装配，不是审批清单，也不是通用 SVG/PPT 双向转换协议。依赖 Python 3 标准库及随 skill 提供的 PNG 校验模块。

从当前 skill 目录解析脚本绝对路径，不假定工作目录就在 skill 下：

```bash
python3 /home/minxi/.codex/skills/text-last-academic-figure/scripts/build_drawio.py --spec scene.json --output layout.drawio --text-free
python3 /home/minxi/.codex/skills/text-last-academic-figure/scripts/build_drawio.py --spec scene.json --output figure.drawio
```

先在项目中准备输出目录。输出已存在时拒绝覆盖：已有母版可能包含手工修改，应读现稿后修改或生成新版本。脚本不读取/合并现有 Draw.io 文件，不做自动布局、自动裁图或导出；需要高级模板可直接按 [官方 Draw.io 格式参考](https://www.drawio.com/docs/reference/diagram-generation/) 生成原生 XML，不必扩展此脚本。

## 最小可运行例

自带 [example.scene.json](../assets/example.scene.json)，用于结构 smoke，不是科研结果图：

```bash
python3 /home/minxi/.codex/skills/text-last-academic-figure/scripts/build_drawio.py --spec /home/minxi/.codex/skills/text-last-academic-figure/assets/example.scene.json --output example.drawio
```

顶层：`canvas.width/height` 为正数；`title` 可选；`nodes` 非空；`edges` 可空；`style` 是节点通用 Draw.io 样式字典。无字模式仅隐藏图中节点/边文字，保留页面名称和图层名。

## 节点

每项包含 `id, x, y, width, height`。可选 `kind`（默认 module）、`text`、`parent`、`layer`、`style`、`note`：

- `module`：原生形状，可选 `shape: rectangle | ellipse | rhombus`，内置可编辑标签。
- `group`：透明容器，无内置文字；子元素相对该容器左上角定位。
- `label`：独立原生文本。可作为 module/group 的子元素共同移动。
- `image`：`asset` 指向本地非隔行 PNG，路径相对 scene 文件（也接受绝对路径）。脚本内嵌原始字节并保持比例，不生成或修改图片。图片名称用同组的 label，不烘焙在位图内。

父节点须先声明，且为 group/module。顶层坐标相对页面；子节点相对父容器并在其边界内。同一个 ID 在节点和边之间也不得重复。

默认图层从后到前为 background、connections、modules、assets、labels。显式 `parent` 优先于图层设置；同组内按照节点声明顺序叠放，背景先、图片其次、标签最后。

常用 `style`：`fillColor, strokeColor, strokeWidth, fontFamily, fontSize, fontColor, fontStyle, align, verticalAlign, dashed, rounded`。使用数字或字符串，非布尔值。脚本固定纯文本 `html=0`，不支持 HTML 标签与公式渲染；XML 转义自动完成。复杂符号/公式走原生编辑器能力并单独验收。

将图标装入一个模块的示意：

```json
[
  {"id":"device","kind":"group","x":40,"y":80,"width":180,"height":160},
  {"id":"device-icon","kind":"image","parent":"device","asset":"assets/device.png","x":30,"y":0,"width":120,"height":110,"note":"已有或生成的无字设备素材"},
  {"id":"device-label","kind":"label","parent":"device","text":"终端","x":0,"y":120,"width":180,"height":30}
]
```

## 边

`id, source, target` 必填，端点必须存在且不是 label。默认正交路由、右侧出左侧入。可选：

- `ports: [exitX, exitY, entryX, entryY]`：各值在 [0,1]，为端点形状的相对位置。
- `points: [[x,y], ...]`：**页面坐标**中间路由点，用于避障/反馈；不是源/终点。
- `text`：随边移动的可编辑文字；`style`：边样式，例如 dashed、endArrow、strokeColor、fontSize。

脚本检查 ID、父子关系、边端点、坐标边界与 PNG 内容。它不测量字体、不检查所有重叠、不证明路由美观；最终必须打开实际 Draw.io/实际导出结果检查。
