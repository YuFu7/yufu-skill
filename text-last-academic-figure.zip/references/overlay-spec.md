# Overlay specification

Legacy mode only: use for an explicitly chosen full-canvas raster background
with vector labels, not for the default hybrid Draw.io workflow. Its canonical
SVG restrictions intentionally reject native diagram geometry. Do not run this
validator on Draw.io SVG exports.

Use UTF-8 JSON. The raster image dimensions must equal `canvas.width` and
`canvas.height`.

```json
{
  "canvas": {
    "width": 1536,
    "height": 1024,
    "physical_width_in": 7.1
  },
  "title": "Editable figure overlay",
  "description": "One text-free raster substrate plus vector labels.",
  "font_family": "Nimbus Sans, Helvetica Neue, Arial, sans-serif",
  "labels": [
    {
      "id": "panel-a",
      "text": "(a) Added context",
      "x": 42,
      "y": 60,
      "anchor": "start",
      "font_size": 35,
      "font_weight": 700,
      "font_style": "normal",
      "fill": "#202832",
      "backplate": {
        "x": 24,
        "y": 20,
        "width": 340,
        "height": 58,
        "rx": 13,
        "fill": "#FFFFFF",
        "fill_opacity": 0.94,
        "stroke": "#D9E0E7",
        "stroke_width": 1.5
      }
    },
    {
      "id": "role-d1",
      "text": "d1",
      "x": 250,
      "y": 590,
      "anchor": "middle",
      "font_size": 24,
      "font_weight": 700,
      "font_style": "italic",
      "collision_box": {
        "x": 222,
        "y": 562,
        "width": 56,
        "height": 38
      }
    }
  ]
}
```

Required top-level fields:

- `canvas.width`, `canvas.height`: positive integer view-box dimensions.
- `labels`: non-empty array.

Optional top-level fields:

- `canvas.physical_width_in`: positive number; physical height is derived from the
  image aspect ratio.
- `title`, `description`: SVG accessibility metadata.
- `font_family`: shared vector-text font stack.

Required label fields:

- `id`: unique XML-safe identifier.
- `text`: non-empty text.
- `x`, `y`: text anchor and baseline coordinates.
- `font_size`: positive number in view-box units.

Optional label fields:

- `anchor`: `start`, `middle`, or `end`.
- `font_weight`: numeric or CSS weight.
- `font_style`: `normal` or `italic`.
- `fill`, `letter_spacing`, `opacity`.
- `backplate`: rounded rectangle behind the label.
- `collision_box`: non-rendered footprint for a label without a backplate.

Every label must provide either `backplate` or `collision_box`, but not both. These
footprints must remain inside the canvas and must not overlap. A text anchor must lie
inside its footprint. Use `collision_box` only when Stage 2 already provides a quiet,
high-contrast region.

The composer preserves both forms in the SVG. A backplate becomes
`rect[data-role="backplate"]`; a collision box becomes a non-rendering
`rect[data-role="collision-footprint"]` with `fill="none"` and `stroke="none"`.
This metadata lets the standalone validator recheck all label footprints without the
JSON file.

The composer rejects duplicate identifiers, out-of-bounds anchors, invalid anchors,
overlapping footprints, invalid optional values, unexpected fields, raster/canvas
dimension mismatches, path-traversing linked assets, and existing outputs unless
`--replace` is explicit.

Text, title, and description must contain at least one renderable Unicode base
character. Control/format-only, zero-width, whitespace-only, and combining-only
strings are rejected. `font_family` is a comma-separated list of nonempty family
names such as `Nimbus Sans, Helvetica Neue, Arial, sans-serif`; empty or comma-only
families are invalid. Generated SVG is canonical UTF-8.
