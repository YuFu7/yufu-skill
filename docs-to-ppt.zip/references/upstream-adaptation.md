# 上游阅读与组合取舍

核对日期：2026-09-13。本 skill 是针对用户偏好的独立改写，没有安装或直接调用两个外部 skill 的完整流程，没有复制它们的代码、图片、风格 JSON 或 worker 模板。若后续实际移植源码，应附相应 MIT 许可与署名。

## codex-ppt

阅读 [ningzimu/codex-ppt-skill](https://github.com/ningzimu/codex-ppt-skill) v0.6.0（仓库最新提交日期 2026-09-12）的主 SKILL、九份流程文档、slide-worker 提示词、科研答辩风参考，以及 prepare_slide_prompts.py 与 assemble_ppt.py。

吸收：先规划再制作、从真实渲染页提取参考风格、稳定风格与可变页型分离、每页自包含任务上下文、严格区分证据素材与风格参考、选定样例复用、局部修复、按最终顺序写备注、个人风格与安装目录分离。

不照搬：整页位图交付及禁止原生文本、2–3 个风格选项/单一样张、强制逐页子代理、共享 API 环境、按文件大小自动有损压缩。改为至少四个图像选型、分层模板、可编辑文字稿确认、原生装配与独立 Draw.io 插图。上游主 SKILL 与生成规则的整页图片约束和本任务不兼容，因此不把它列为必须执行的依赖。

## grill-with-docs

阅读用户给出的 [文档](https://github.com/mattpocock/skills/blob/main/docs/engineering/grill-with-docs.md)，并核对其 [入口](https://github.com/mattpocock/skills/blob/main/skills/engineering/grill-with-docs/SKILL.md)、[grilling](https://github.com/mattpocock/skills/blob/main/skills/productivity/grilling/SKILL.md) 与 [domain-modeling](https://github.com/mattpocock/skills/blob/main/skills/engineering/domain-modeling/SKILL.md)。

吸收：依赖已解决才问下一轮、建议伴随问题、事实由 agent 查证、回答及时落盘、术语歧义主动澄清。适配为 PPT 项目的 brief 与逐页大纲，记录所有影响 PPT 的关键决定，不局限于术语和达到 ADR 条件的决定；不修改研究项目根目录的领域模型，不依赖不存在的 Skill 工具或两个未安装的子 skill。

## Draw.io 与本地 skill

复用现有 text-last-academic-figure 的原生结构＋独立位图思路与 WSL 后端说明，增加页面槽位、字体缩放、图内外语义一致性和编辑级别说明。整个 PPT 叙事是“先文后图”；单幅图内部仍可“结构先行、文字最后定稿”，二者不冲突。

## Codex skill 结构

按 [OpenAI 官方 skill 指南](https://learn.chatgpt.com/docs/build-skills) 与本地 skill-creator，将发现描述、主流程、按需参考和确定性装配脚本分开。默认可被匹配发现；没有复制上游 explicit-only 设置。人工等待点来自用户本次明确要求，不是对所有 PPT 任务增加审批；普通一次性制作仍由 paper-slides 等技能处理。

图像生成使用当前 imagegen 的实际能力，不绑定某个模型版本、不因路径便利改用 API；不把上游源码写的默认模型名当成本机已使用模型的证据。
