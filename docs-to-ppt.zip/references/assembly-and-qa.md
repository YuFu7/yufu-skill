# 原生装配、文字审阅与最终检查

## 项目文件

brief.md 保留范围、术语、选定样板路径、人工决定及当前待决项；outline.md 是人读的叙事主本；deck.json 是与当前叙事同步的装配输入。修改内容时同步二者，不保留两份矛盾的“最终版本”。模板参数在 style/，图像/Draw.io 母版在 assets/、figures/，生成预览在 build/。

style 中的候选和项目 build 中的草稿不得通过目录 glob 混入最终 PPT。最终页面顺序由显式 slides 数组决定，slide_id 稳定；插页/重排也要同步备注、素材映射和引用。

保留源文档只读，必要时复制使用。用户在 PPT 上的手工修改属于用户成果；重新生成前读回其文字与布局，或生成新版本供比较，不静默覆盖。

## 装配助手

scripts/build_deck.py 支持 Python 3 + python-pptx + Pillow，使用项目环境；不自动创建共享环境或联网装依赖。项目缺少依赖时在其独立环境安装，不修改其他项目。脚本没有外部 API 调用。

从当前 skill 所在位置解析脚本绝对路径，调用：

```text
python <skill>/scripts/build_deck.py --spec <project>/deck.json --mode text --output <project>/build/text-review.pptx
python <skill>/scripts/build_deck.py --spec <project>/deck.json --mode final --output <project>/deck-v1.pptx
```

mode=text：保留所有实际文字和设计形状，图片/表格显示占位说明，不读取未完成图片；用于纯文字叙事确认。不要在文字稿中放实际图像/数值表来替代后续视觉阶段。图注和关键表格结论应作为 text 元素出现，可被此轮审阅。

mode=final：插入提供的图片和原生表格，缺少必需文件就报错；不因没有图片而悄悄少一页或交付占位框。脚本不检查人是否批准，必须由 agent 按主流程等待确认后调用。

输出文件默认独占创建，不覆盖已存在的 PPTX。自带 assets/review-example.json 是纯结构 smoke 示例，不是用户已批准样板，也不是图像生成的候选。

## 最小输入结构

```json
{
  "title": "文档驱动汇报",
  "canvas": {"width": 13.3333333333, "height": 7.5},
  "theme": {
    "font_latin": "Times New Roman",
    "font_east_asian": "Microsoft YaHei",
    "background": "FFFFFF",
    "text": "111111",
    "blue": "1F4E79",
    "red": "B22222"
  },
  "slides": [{
    "id": "S01",
    "title": "本页核心信息",
    "source_refs": ["report.pdf p.5 图2"],
    "notes": "可选讲稿，不是内部决策记录。",
    "elements": [
      {"id": "title", "type": "text", "x": 0.6, "y": 0.35, "w": 12.1, "h": 0.6,
       "text": "本页核心信息", "font_size": 30, "bold": true},
      {"id": "body", "type": "text", "x": 0.6, "y": 1.4, "w": 4.6, "h": 4.5,
       "text": "已确认的实际论述\n第二个必要要点", "font_size": 22},
      {"id": "mechanism", "type": "image", "x": 5.7, "y": 1.4, "w": 7, "h": 4.5,
       "path": "figures/mechanism/figure.png", "placeholder": "机制图：输入—方法—输出"}
    ]
  }]
}
```

元素公共字段：id、type、x/y/w/h（页面英寸坐标）。同页元素 id 唯一；坐标必须在画布内。为忠实实现样板可自行扩展项目构建代码，不强迫所有布局挤进本助手。

- text：text 或 paragraphs（两者二选一）；font_size 单位 pt，color 六位十六进制；bold/italic、align=left/center/right 可选。paragraphs 是段落列表，每段可由若干 runs 组成，每 run 有 text、可选 color/bold/italic/font_size，便于红蓝短语强调。脚本不自动缩字或省略文案。
- box：可选 fill、line、line_width；背景容器按元素顺序先画。纯装饰背景仍需符合已批准样板。
- image：path 相对 deck.json；placeholder 用于文字稿。支持 PNG/JPEG 等 python-pptx 实际支持的栅格格式，等比 contain、保留原文件，不做有损压缩或裁切。
- table：rows 为相同列数的非空字符串二维数组；header 默认 true、font_size 默认 18、可选 column_widths（英寸且总和等于 w）。text 模式只显示 placeholder。最终数值必须来自资料，脚本不生成统计数据。

所有可见内容都显式放入 elements；不会自动添加标题/页码，以免与选定版式重复。slide.title 是结构元数据，不是自动可见标题。notes 可写入讲者备注；source_refs 供溯源，不自动公开，面向观众的引用请放显式 text 元素。

脚本给每个文本 run 同时设置 Latin 与 East Asian 字体声明，覆盖混排；不嵌入字体文件，也不能保证目标机器装有字体。引用的字体缺失时说明问题，优先使用宿主机已安装字体渲染，不默默改成其他字体后声称完全匹配。

## 实际渲染与人工检查

优先已有 PowerPoint/LibreOffice/项目渲染工具，使用独立构建输出目录。WSL 调用宿主程序时转换输入、输出路径，不关闭用户原有文档、不假称连接了未验证的窗口。工具不具备时，XML/ZIP 检查只能说明文件结构正常，不能说明版面已验收。

Windows 已安装 PowerPoint 且允许 COM 时可用 scripts/render_powerpoint.ps1，通过 PowerShell 的 -File 调用，参数为 -InputPptx <Windows路径> -OutputDirectory <新的Windows目录>；默认 1600×900 PNG。WSL 中先用 wslpath -w 转换脚本、输入、输出三类路径。脚本只读打开指定文件并关闭自己打开的演示稿，不关闭原有用户文档；输出目录存在时拒绝覆盖。受执行策略/沙箱/Office 状态阻拦时报告实际错误，不关闭安全设置或强行结束 Office 进程。

先检查一个代表复杂页的字体、图表与导出，再渲染整套实际 PPTX；逐页查看：

- 与已确认大纲一致；没有偷加新 claim、研究进展或生成的假数据；来源对应正确。
- 标题/正文/脚注无乱码、溢出、截断；中英文混排字体正确，投影尺寸可读。
- 槽位内图片等比且完整，坐标轴/图例/单位未被裁掉；原生表格数据正确。
- 原生文本/表格仍是对象，Draw.io 插图的编辑级别说明准确；没有误贴整张样板背景。

再看全套缩略预览：重复页型是否单调、叙事节奏是否适合时长、主线能否从页标题读通、密度是否失衡。发现问题修相应页/样式，复查受影响页；不按任意评分无限重生成。

讲稿需要时按听众和时间写，解释图的阅读顺序与“为什么重要”，不照读正文。段落长度服从每页时长，不机械执行每页 150–400 字。备注也按 stable slide_id 与最终顺序同步。

最终报告给 PPTX 路径、页数、源文件/母版位置与验证范围即可；PDF、整套预览、讲稿按用户需要。不默认 HTML、不默认导出每一种格式。
