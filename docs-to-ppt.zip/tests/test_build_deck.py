"""Finite tests of native objects and mode behavior, not human design approval."""

import copy
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zipfile

from PIL import Image
from pptx import Presentation
from pptx.oxml.ns import qn

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from build_deck import build


class BuildDeckTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.spec = json.loads((ROOT / "assets/review-example.json").read_text())

    def tearDown(self):
        self.tmp.cleanup()

    def test_text_mode_works_without_figure_and_declares_fonts(self):
        payload, stats = build(self.spec, self.base, "text")
        self.assertEqual(stats["placeholders"], 1)
        self.assertEqual(stats["images"], 0)
        prs = Presentation(io.BytesIO(payload))
        self.assertAlmostEqual(prs.slide_width / prs.slide_height, 16 / 9)
        slide = prs.slides[0]
        self.assertIn("先确认叙事", slide.shapes[0].text)
        rpr = slide.shapes[0].text_frame.paragraphs[0].runs[0]._r.rPr
        self.assertEqual(rpr.find(qn("a:latin")).get("typeface"), "Times New Roman")
        self.assertEqual(rpr.find(qn("a:ea")).get("typeface"), "Microsoft YaHei")
        self.assertEqual(self.spec["slides"][0]["notes"], slide.notes_slide.notes_text_frame.text)

    def test_final_missing_asset_fails(self):
        with self.assertRaises(FileNotFoundError):
            build(self.spec, self.base, "final")

    def test_final_native_table_and_unmodified_image(self):
        # Synthetic pixels are only a transport fixture, not a generated research asset.
        path = self.base / "fixture.png"
        Image.new("RGBA", (200, 100), (20, 60, 120, 128)).save(path)
        elements = self.spec["slides"][0]["elements"]
        elements[2]["path"] = str(path)
        elements.append({"id": "table", "type": "table", "x": 0.6, "y": 5.8,
                         "w": 6, "h": 0.9, "rows": [["项目", "状态"], ["测试", "示例"]],
                         "column_widths": [2, 4]})
        payload, stats = build(self.spec, self.base, "final")
        self.assertEqual((stats["images"], stats["tables"]), (1, 1))
        prs = Presentation(io.BytesIO(payload))
        picture = prs.slides[0].shapes[2]
        self.assertAlmostEqual(picture.width / picture.height, 2)
        self.assertEqual(prs.slides[0].shapes[-1].table.cell(1, 0).text, "测试")
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            media = [n for n in archive.namelist() if n.startswith("ppt/media/")]
            self.assertEqual(len(media), 1)
            self.assertEqual(archive.read(media[0]), path.read_bytes())

    def test_order_is_explicit_and_invalid_ids_bounds_fail(self):
        second = copy.deepcopy(self.spec["slides"][0])
        second["id"] = "S09"
        self.spec["slides"].insert(0, second)
        payload, _ = build(self.spec, self.base, "text")
        self.assertTrue(Presentation(io.BytesIO(payload)).slides[0].shapes[0].name.startswith("S09/"))
        self.spec["slides"][1]["id"] = "S09"
        with self.assertRaises(ValueError):
            build(self.spec, self.base, "text")
        self.spec["slides"].pop()
        self.spec["slides"][0]["elements"][0]["w"] = float("nan")
        with self.assertRaises(ValueError):
            build(self.spec, self.base, "text")

    def test_cli_no_overwrite(self):
        output = self.base / "review.pptx"
        command = [sys.executable, "-B", str(ROOT / "scripts/build_deck.py"),
                   "--spec", str(ROOT / "assets/review-example.json"),
                   "--mode", "text", "--output", str(output)]
        first = subprocess.run(command, text=True, capture_output=True)
        self.assertEqual(first.returncode, 0, first.stderr)
        saved = output.read_bytes()
        self.assertEqual(subprocess.run(command, capture_output=True).returncode, 2)
        self.assertEqual(saved, output.read_bytes())


if __name__ == "__main__":
    unittest.main()
