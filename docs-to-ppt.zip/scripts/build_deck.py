#!/usr/bin/env python3
"""Build an explicitly laid-out native text-review or final PPTX; no AI calls."""

from __future__ import annotations

import argparse
import io
import json
import math
from pathlib import Path
import re
import sys

from PIL import Image
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.xmlchemy import OxmlElement
from pptx.util import Inches, Pt


THEME = {"font_latin": "Times New Roman", "font_east_asian": "Microsoft YaHei",
         "background": "FFFFFF", "text": "111111", "blue": "1F4E79", "red": "B22222"}
ALIGN = {"left": PP_ALIGN.LEFT, "center": PP_ALIGN.CENTER, "right": PP_ALIGN.RIGHT}


def finite(value, name, positive=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be numeric")
    if not math.isfinite(value) or (positive and value <= 0):
        raise ValueError(f"{name} must be finite" + (" and positive" if positive else ""))
    return value


def color(value):
    if not isinstance(value, str) or not re.fullmatch(r"#?[0-9A-Fa-f]{6}", value):
        raise ValueError(f"expected six-digit RGB color, got {value!r}")
    return RGBColor.from_string(value.lstrip("#").upper())


def format_run(run, style, theme):
    run.font.name = theme["font_latin"]
    run.font.size = Pt(finite(style.get("font_size", 22), "font_size", True))
    run.font.bold = style.get("bold", False)
    run.font.italic = style.get("italic", False)
    run.font.color.rgb = color(style.get("color", theme["text"]))
    rpr = run._r.get_or_add_rPr()
    rpr.set("lang", "en-US")
    rpr.set("altLang", "zh-CN")
    # Explicit per-script families avoid Latin-only font.name losing CJK intent.
    for tag, family in (("a:latin", theme["font_latin"]),
                        ("a:ea", theme["font_east_asian"]),
                        ("a:cs", theme["font_latin"])):
        child = rpr.find(tag, rpr.nsmap)
        if child is None:
            child = OxmlElement(tag)
            rpr.append(child)
        child.set("typeface", family)


def fill_text(frame, element, theme):
    if "text" in element and "paragraphs" in element:
        raise ValueError("text and paragraphs are mutually exclusive")
    if "paragraphs" in element:
        paragraphs = element["paragraphs"]
    else:
        value = element.get("text", "")
        if not isinstance(value, str):
            raise ValueError("text must be a string")
        paragraphs = [{"runs": [{"text": line}]} for line in value.split("\n")]
    if not isinstance(paragraphs, list) or not paragraphs:
        raise ValueError("paragraphs must be a non-empty list")
    frame.clear()
    frame.word_wrap = True
    frame.vertical_anchor = MSO_ANCHOR.TOP
    frame.margin_left = frame.margin_right = Inches(0.03)
    frame.margin_top = frame.margin_bottom = Inches(0.03)
    for index, entry in enumerate(paragraphs):
        paragraph = frame.paragraphs[0] if index == 0 else frame.add_paragraph()
        paragraph.alignment = ALIGN[element.get("align", "left")]
        paragraph.space_after = Pt(10)
        paragraph.line_spacing = 1.1
        for item in entry["runs"]:
            if not isinstance(item["text"], str):
                raise ValueError("run text must be a string")
            run = paragraph.add_run()
            run.text = item["text"]
            format_run(run, {**element, **item}, theme)


def rect(slide, bounds, fill=None, line=None, line_width=1):
    shape = slide.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.RECTANGLE, *bounds)
    if fill:
        shape.fill.solid()
        shape.fill.fore_color.rgb = color(fill)
    else:
        shape.fill.background()
    if line:
        shape.line.color.rgb = color(line)
        shape.line.width = Pt(finite(line_width, "line_width", True))
    else:
        shape.line.fill.background()
    return shape


def build(spec, base_dir, mode):
    if mode not in ("text", "final"):
        raise ValueError("mode must be text or final")
    canvas = spec.get("canvas", {"width": 40 / 3, "height": 7.5})
    width = finite(canvas["width"], "canvas.width", True)
    height = finite(canvas["height"], "canvas.height", True)
    theme = {**THEME, **spec.get("theme", {})}
    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(width), Inches(height)
    prs.core_properties.title = spec.get("title", "Document-grounded presentation")
    slides = spec["slides"]
    if not isinstance(slides, list) or not slides:
        raise ValueError("slides must be non-empty")
    seen = set()
    stats = {"slides": len(slides), "text": 0, "images": 0, "tables": 0, "placeholders": 0}
    for page in slides:
        if not isinstance(page["id"], str) or not page["id"] or page["id"] in seen:
            raise ValueError("slide IDs must be non-empty and unique")
        seen.add(page["id"])
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        slide.background.fill.solid()
        slide.background.fill.fore_color.rgb = color(theme["background"])
        element_ids = set()
        for element in page["elements"]:
            ident = element["id"]
            if not isinstance(ident, str) or not ident or ident in element_ids:
                raise ValueError(f"{page['id']}: element IDs must be non-empty and unique")
            element_ids.add(ident)
            x, y, w, h = [finite(element[k], f"{ident}.{k}", k in ("w", "h"))
                          for k in ("x", "y", "w", "h")]
            if x < 0 or y < 0 or x + w > width + 1e-6 or y + h > height + 1e-6:
                raise ValueError(f"{page['id']}/{ident}: outside slide")
            bounds = tuple(Inches(v) for v in (x, y, w, h))
            kind = element["type"]
            if kind == "text":
                shape = slide.shapes.add_textbox(*bounds)
                fill_text(shape.text_frame, element, theme)
                stats["text"] += 1
            elif kind == "box":
                shape = rect(slide, bounds, element.get("fill"), element.get("line"),
                             element.get("line_width", 1))
            elif kind in ("image", "table") and mode == "text":
                shape = rect(slide, bounds, "F7F8FA", "D9DEE5")
                fill_text(shape.text_frame, {"text": element.get("placeholder", f"{kind} 预留区"),
                                             "font_size": 16, "color": "666666"}, theme)
                stats["placeholders"] += 1
            elif kind == "image":
                path = Path(element["path"])
                path = path if path.is_absolute() else base_dir / path
                with Image.open(path) as image:
                    iw, ih = image.size
                scale = min(w / iw, h / ih)
                pw, ph = iw * scale, ih * scale
                shape = slide.shapes.add_picture(str(path), Inches(x + (w - pw) / 2),
                                                 Inches(y + (h - ph) / 2),
                                                 width=Inches(pw), height=Inches(ph))
                stats["images"] += 1
            elif kind == "table":
                rows = element["rows"]
                if (not isinstance(rows, list) or not rows or not isinstance(rows[0], list)
                        or not rows[0] or any(not isinstance(row, list) or len(row) != len(rows[0])
                                            or any(not isinstance(v, str) for v in row) for row in rows)):
                    raise ValueError("table rows must be a non-empty rectangular array of strings")
                shape = slide.shapes.add_table(len(rows), len(rows[0]), *bounds)
                table = shape.table
                table.first_row = element.get("header", True)
                table.horz_banding = False
                if "column_widths" in element:
                    widths = element["column_widths"]
                    if len(widths) != len(rows[0]) or abs(sum(finite(v, "column width", True) for v in widths) - w) > 1e-6:
                        raise ValueError("column_widths must match column count and sum to table w")
                    for column, col_w in zip(table.columns, widths):
                        column.width = Inches(col_w)
                for row_index, row in enumerate(rows):
                    for col_index, value in enumerate(row):
                        cell = table.cell(row_index, col_index)
                        header = row_index == 0 and element.get("header", True)
                        cell.fill.solid()
                        cell.fill.fore_color.rgb = color("F2F4F7" if header else theme["background"])
                        fill_text(cell.text_frame, {"text": value, "bold": header,
                                                   "font_size": element.get("font_size", 18)}, theme)
                stats["tables"] += 1
            else:
                raise ValueError(f"unsupported element type: {kind}")
            shape.name = page["id"] + "/" + ident
        if page.get("notes"):
            fill_text(slide.notes_slide.notes_text_frame,
                      {"text": page["notes"], "font_size": 12}, theme)
    output = io.BytesIO()
    prs.save(output)
    return output.getvalue(), stats


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", required=True, type=Path)
    parser.add_argument("--mode", required=True, choices=("text", "final"))
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    try:
        if args.output.suffix.lower() != ".pptx":
            raise ValueError("output must end with .pptx")
        spec = json.loads(args.spec.read_text(encoding="utf-8"))
        payload, stats = build(spec, args.spec.resolve().parent, args.mode)
        # Do not overwrite manually edited presentations or leave partial output on build failure.
        with args.output.open("xb") as output:
            output.write(payload)
        print(json.dumps({"output": str(args.output), "mode": args.mode, **stats,
                          "visual_verified": False, "user_approval_checked": False}, ensure_ascii=False))
        return 0
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
