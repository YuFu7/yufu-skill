# Export only the specified deck; never close unrelated user presentations.
param(
    [Parameter(Mandatory = $true)][string]$InputPptx,
    [Parameter(Mandatory = $true)][string]$OutputDirectory,
    [int]$Width = 1600,
    [int]$Height = 900
)
$ErrorActionPreference = "Stop"
if (-not (Test-Path -LiteralPath $InputPptx -PathType Leaf)) { throw "Input PPTX does not exist." }
if (Test-Path -LiteralPath $OutputDirectory) { throw "Output directory already exists; choose a new path." }
if ($Width -le 0 -or $Height -le 0) { throw "Export dimensions must be positive." }
$wasRunning = @(Get-Process -Name POWERPNT -ErrorAction SilentlyContinue).Count -gt 0
$pptApp = $null
$pptDeck = $null
try {
    $pptApp = New-Object -ComObject PowerPoint.Application
    $inputName = [IO.Path]::GetFileName($InputPptx)
    foreach ($existing in $pptApp.Presentations) {
        if ($existing.Name -eq $inputName) {
            throw "A presentation with this filename is already open; render a separately named working copy."
        }
    }
    # ReadOnly=true, Untitled=false, WithWindow=false.
    $pptDeck = $pptApp.Presentations.Open($InputPptx, -1, 0, 0)
    $expectedRatio = $pptDeck.PageSetup.SlideWidth / $pptDeck.PageSetup.SlideHeight
    if ([Math]::Abs($Width / $Height - $expectedRatio) -gt 0.01) {
        throw "Export dimensions would change the slide aspect ratio."
    }
    New-Item -ItemType Directory -Path $OutputDirectory | Out-Null
    $pptDeck.Export($OutputDirectory, "PNG", $Width, $Height)
    $images = @(Get-ChildItem -LiteralPath $OutputDirectory -Filter "*.PNG" -File)
    if ($images.Count -ne $pptDeck.Slides.Count) { throw "Exported image count differs from slide count." }
    [pscustomobject]@{
        input = $InputPptx
        output = $OutputDirectory
        slides = $pptDeck.Slides.Count
        renderer = "Windows PowerPoint"
        visual_inspection = "pending"
    } | ConvertTo-Json
}
finally {
    if ($null -ne $pptDeck) {
        $pptDeck.Close()
        [void][Runtime.InteropServices.Marshal]::ReleaseComObject($pptDeck)
    }
    if ($null -ne $pptApp) {
        if (-not $wasRunning -and $pptApp.Presentations.Count -eq 0) { $pptApp.Quit() }
        [void][Runtime.InteropServices.Marshal]::ReleaseComObject($pptApp)
    }
}
